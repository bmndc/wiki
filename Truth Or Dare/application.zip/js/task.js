var playernames = JSON.parse(localStorage.getItem("current"));
var gametype = sessionStorage.getItem("type");
var turn = +sessionStorage.getItem("turn");
var tasktype = sessionStorage.getItem("task");
var scoremass = JSON.parse(sessionStorage.getItem("score"));
var skiptruth = JSON.parse(sessionStorage.getItem("skiptruth"));
var skipdare = JSON.parse(sessionStorage.getItem("skipdare"));

var questionmass = [];

if (gametype=="kids" && tasktype=="truth") { questionmass=kidstruth; }
if (gametype=="kids" && tasktype=="dare") { questionmass=kidsdare; }
if (gametype=="teenagers" && tasktype=="truth") { questionmass=teenagerstruth; }
if (gametype=="teenagers" && tasktype=="dare") { questionmass=teenagersdare; }
if (gametype=="adults" && tasktype=="truth") { questionmass=adultstruth; }
if (gametype=="adults" && tasktype=="dare") { questionmass=adultsdare; }
if (gametype=="couples" && tasktype=="truth") { questionmass=couplestruth; }
if (gametype=="couples" && tasktype=="dare") { questionmass=couplesdare; }


if ((tasktype=="truth" && skiptruth.length+1==questionmass.length) || (tasktype=="dare" && skipdare.length+1==questionmass.length)) {
	window.open("result.html","_self");
}

var rand = Math.floor(Math.random() * questionmass.length);

while ((tasktype=="truth" && skiptruth.includes(rand))|| (tasktype=="dare" && skipdare.includes(rand))) {
  rand = Math.floor(Math.random() * questionmass.length);
}


if (tasktype=="truth") {
	skiptruth.push(rand);
	sessionStorage.setItem("skiptruth", JSON.stringify(skiptruth));	
}

if (tasktype=="dare") {
	skipdare.push(rand);
	sessionStorage.setItem("skipdare", JSON.stringify(skipdare));	
}

document.getElementById("player").innerHTML=playernames[turn]+" 's turn!";
document.getElementById("task").innerHTML=questionmass[rand];


function nextturn() {
	turn++;
	if (turn>playernames.length-1) { turn=0; }
	sessionStorage.setItem("turn",turn);
	window.open("game.html","_self");
}


function handleKeydown(e) {
  switch(e.key) {
    case 'ArrowUp':
      nav(-1);
      break;
    case 'ArrowDown':
      nav(1);
      break;
    case 'ArrowRight':
	e.preventDefault();
      nav(1);
      break;
    case 'ArrowLeft': 
	e.preventDefault();
      nav(-1);
      break;
    case 'SoftLeft':
      softkeyCallback.left();
      break;
    case 'SoftRight':
      softkeyCallback.right();
      break;
    case 'Enter':
      softkeyCallback.center();
      break;
	case 'Backspace':
	  e.preventDefault();
	  softkeyCallback.back();		
	break;
  }
};

function nav (move) {
  var currentIndex = document.activeElement.tabIndex;
  var items = document.querySelectorAll('.items');
  var next = currentIndex + move;
  if (next>items.length-1) {next=items.length-1;} else if (next<0) {next=0;}
  var targetElement = items[next];
  targetElement.focus();
};

const softkeyCallback = {
	
	back: function() { 
		nextturn(); 
     },
	
    left: function() { 

     },
  
    center: function() { 
		var chk = document.activeElement;
		
		if (chk.id=="forfeit") { 
			nextturn();
		}
		
		if (chk.id=="done") { 
			scoremass[turn]=scoremass[turn]+1;
			sessionStorage.setItem("score", JSON.stringify(scoremass));	
			nextturn();
		}
      },
  
    right: function() { 
		
     }
};

document.addEventListener('keydown', handleKeydown);