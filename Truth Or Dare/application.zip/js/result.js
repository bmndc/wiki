var playernames = JSON.parse(localStorage.getItem("current"));
var scoremass = JSON.parse(sessionStorage.getItem("score"));

var res = "";

for (var i=0;i<playernames.length;i++) {
	res = res + playernames[i]+": "+scoremass[i]+"<br>";
}

document.getElementById("results").innerHTML=res;


function handleKeydown(e) {
  switch(e.key) {
    case 'SoftLeft':
      softkeyCallback.left();
      break;
    case 'SoftRight':
      softkeyCallback.right();
      break;
    case 'Enter':
      softkeyCallback.center();
      break;
	case 'Backspace':
	  e.preventDefault();
	  softkeyCallback.back();		
	break;
  }
};


const softkeyCallback = {
	
	back: function() { 
		window.open("index.html","_self"); 
     },
	
    left: function() { 

     },
  
    center: function() { 

      },
  
    right: function() { 
		window.open("index.html","_self"); 
     }
};

document.addEventListener('keydown', handleKeydown);

document.addEventListener("DOMContentLoaded", () => {
	getKaiAd({
	publisher: 'ef30ef98-e411-4952-89b7-4cf1e1bb4437',
	app: 'truthordare',
	slot: 'fullscreen',
	test: 0,
	onerror: err => console.error('Custom catch:', err),
	onready: ad => {
		ad.call('display')
		
		// user clicked the ad
		ad.on('click', () => console.log('click event') )

		// user closed the ad (currently only with fullscreen)
		ad.on('close', () => document.addEventListener('keydown', handleKeydown) )

		// the ad succesfully displayed
		ad.on('display', () => document.removeEventListener('keydown', handleKeydown) )
	}
})
});	