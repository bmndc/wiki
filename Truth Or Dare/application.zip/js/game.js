var playernames = JSON.parse(localStorage.getItem("current"));
var gametype = sessionStorage.getItem("type");
var turn = +sessionStorage.getItem("turn");

document.getElementById("player").innerHTML=playernames[turn]+"'s turn!";


function handleKeydown(e) {
  switch(e.key) {
    case 'ArrowUp':
      nav(-1);
      break;
    case 'ArrowDown':
      nav(1);
      break;
    case 'ArrowRight':
      nav(1);
      break;
    case 'ArrowLeft': 
      nav(-1);
      break;
    case 'SoftLeft':
      softkeyCallback.left();
      break;
    case 'SoftRight':
      softkeyCallback.right();
      break;
    case 'Enter':
      softkeyCallback.center();
      break;
	case 'Backspace':
	  e.preventDefault();
	  softkeyCallback.back();		
	break;
  }
};

function nav (move) {
  var currentIndex = document.activeElement.tabIndex;
  var items = document.querySelectorAll('.items');
  var next = currentIndex + move;
  if (next>items.length-1) {next=items.length-1;} else if (next<0) {next=0;}
  var targetElement = items[next];
  targetElement.focus();
};

const softkeyCallback = {
	
	back: function() { 
		window.open("result.html","_self"); 
     },
	
    left: function() { 
		window.open("result.html","_self"); 
     },
  
    center: function() { 
		var chk = document.activeElement;
		
		if (chk.id=="truth") { sessionStorage.setItem("task","truth"); window.open("task.html","_self"); }
		if (chk.id=="dare") { sessionStorage.setItem("task","dare"); window.open("task.html","_self"); }
      },
  
    right: function() { 
		
     }
};

document.addEventListener('keydown', handleKeydown);