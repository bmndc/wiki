if (localStorage.getItem("current")) {
	var mass = JSON.parse(localStorage.getItem("current"));
	for (var i=0;i<mass.length;i++) {
		document.getElementById("choice"+(i+1)).value=mass[i];
	}
}

function handleKeydown(e) {
  switch(e.key) {
    case 'ArrowUp':
      nav(-1);
      break;
    case 'ArrowDown':
      nav(1);
      break;
    case 'SoftLeft':
      softkeyCallback.left();
      break;
    case 'SoftRight':
      softkeyCallback.right();
      break;
    case 'Enter':
      softkeyCallback.center();
      break;
	case 'Backspace':
	  e.preventDefault();
	  softkeyCallback.back();		
	break;

  }
};

function nav (move) {
  var currentIndex = document.activeElement.tabIndex;
  var items = document.querySelectorAll('.items');
  var next = currentIndex + move;
  if (next>items.length-1) {next=items.length-1;} else if (next<0) {next=0;}
  var targetElement = items[next];
  targetElement.focus();
};



const softkeyCallback = {
	
	back: function() { 
      window.open("index.html","_self"); 
     },
	
    left: function() { 
	  window.open("index.html","_self");
     },
  
    center: function() { 

      },
  
    right: function() { 
		save();
     }
};

document.addEventListener('keydown', handleKeydown);

window.addEventListener("load", function() {
  var items = document.querySelectorAll('.items');
  var targetElement = items[0];
  targetElement.focus();
});

function save() {
	var flag = true;
	var empt = 0;
	for (var i=1;i<=10;i++) {
		if (document.getElementById("choice"+i).value.trim()=="") {empt++;}
	}
	if (empt>8) { 
	document.getElementById("info").style.backgroundColor="#ff3232";
	flag=false;
	setTimeout(() => document.getElementById("info").style.backgroundColor="", 1000);
	}
	if (flag==true) {
			var tempmass = [];
				for (var i=1;i<=10;i++) {
				if (document.getElementById("choice"+i).value.trim()!="") {
					tempmass.push(document.getElementById("choice"+i).value.trim());
					}
				}
		localStorage.setItem("current", JSON.stringify(tempmass));	
		sessionStorage.setItem("turn","0");
		var scoremass = [0,0,0,0,0,0,0,0,0,0];
		sessionStorage.setItem("score", JSON.stringify(scoremass));	
		var skiptruth = [];
		var skipdare = [];
		sessionStorage.setItem("skiptruth", JSON.stringify(skiptruth));	
		sessionStorage.setItem("skipdare", JSON.stringify(skipdare));	
		window.open("game.html","_self"); 
	}
}