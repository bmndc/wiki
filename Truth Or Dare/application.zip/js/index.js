var w = window.screen.width;
var h = window.screen.height;
if (w>=h) { 
	document.getElementById("logo").remove();
 }

function handleKeydown(e) {
  switch(e.key) {
    case 'ArrowUp':
      nav(-1);
      break;
    case 'ArrowDown':
      nav(1);
      break;
    case 'ArrowRight':
      nav(1);
      break;
    case 'ArrowLeft': 
      nav(-1);
      break;
    case 'SoftLeft':
      softkeyCallback.left();
      break;
    case 'SoftRight':
      softkeyCallback.right();
      break;
    case 'Enter':
      softkeyCallback.center();
      break;
  }
};

function nav (move) {
  var currentIndex = document.activeElement.tabIndex;
  var items = document.querySelectorAll('.items');
  var next = currentIndex + move;
  if (next>items.length-1) {next=items.length-1;} else if (next<0) {next=0;}
  var targetElement = items[next];
  targetElement.focus();
};



const softkeyCallback = {
    left: function() { 

     },
  
    center: function() { 
	var chk = document.activeElement;
	
	if (chk.id=="kids") { sessionStorage.setItem("type","kids"); window.open("new.html","_self"); }
	if (chk.id=="teenagers") { sessionStorage.setItem("type","teenagers"); window.open("new.html","_self"); }
	if (chk.id=="adults") { sessionStorage.setItem("type","adults"); window.open("new.html","_self"); }
	if (chk.id=="couples") { sessionStorage.setItem("type","couples"); window.open("new.html","_self"); }
	if (chk.id=="help") { window.open("help.html","_self"); }

      },
  
    right: function() { 

     }
};

document.addEventListener('keydown', handleKeydown);

window.addEventListener("load", function() {
  var items = document.querySelectorAll('.items');
  var targetElement = items[0];
  targetElement.focus();
});

document.addEventListener("DOMContentLoaded", () => {
	getKaiAd({
	publisher: 'ef30ef98-e411-4952-89b7-4cf1e1bb4437',
	app: 'truthordare',
	slot: 'fullscreen',
	test: 0,
	onerror: err => console.error('Custom catch:', err),
	onready: ad => {
		ad.call('display')
		
		// user clicked the ad
		ad.on('click', () => console.log('click event') )

		// user closed the ad (currently only with fullscreen)
		ad.on('close', () => document.addEventListener('keydown', handleKeydown) )

		// the ad succesfully displayed
		ad.on('display', () => document.removeEventListener('keydown', handleKeydown) )
	}
})
});	