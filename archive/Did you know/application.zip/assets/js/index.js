var tapCounter = 0;
var bannerAdReady = false;

$(document).ready(function() {
  getFact();
});

function getFact() {
  let html_text = '';
  $.getJSON('https://uselessfacts.jsph.pl/random.json?language=en', function(
    json
  ) {
    html_text = json.text;

    $('.fact').empty();
    $('.fact').append(html_text);
  });
}

function getNewAd() {
  getKaiAd({
    publisher: 'bc247e7b-cd8a-4dda-be8c-e766a729f6b8',
    app: 'Did you know',
    slot: 'dykTenTapsFS',
    onerror: err => console.error(err),
    onready: ad => {
      ad.call('display');
    }
  });
}

document.addEventListener('keydown', event => {
  let content = document.getElementById('content');

  switch (event.key) {
    case 'SoftRight':
    case 'Enter':
      // For neglecting the bubbling/propagation of 'Enter' event of ad
      if (event.target === document.body) {
        if (navigator.onLine) {
          getFact();

          tapCounter = tapCounter + 1;

          content.scrollTo(0, 0);

          if (tapCounter % 10 === 0) {
            getNewAd();
          }
        } else {
          showSnackbar();
        }
      }
      break;
    case 'SoftLeft':
      if (bannerAdReady === true) {
        // as there is only one element having class 'ad-class'
        // const ad = document.getElementsByClassName('ad-class')[0];
        const ad = document.querySelector('.ad-class');

        ad.focus();
        // ad.click();

        const adEvent = new KeyboardEvent('keydown', {
          bubbles: true,
          cancelBubble: true,
          cancelable: true,
          defaultPrevented: true,
          key: 'Enter',
          keyCode: 13,
          which: 13
        });
        ad.dispatchEvent(adEvent);

        ad.blur();
      }
      break;
    case 'ArrowDown':
      content.scrollBy(0, 50);
      break;
    case 'ArrowUp':
      content.scrollBy(0, -50);
      break;
    default:
      break;
  }
});

function showSnackbar() {
  var x = document.getElementById('snackbar');
  x.className = 'show';
  setTimeout(function() {
    x.className = x.className.replace('show', '');
  }, 3000);
}

function loadAdContainer() {
  bannerAdReady = true;
  document.getElementById('ad-container').classList.remove('hidden');
  document.getElementById('btn-ad').classList.remove('hidden');
}

document.addEventListener('DOMContentLoaded', () => {
  // Full screen ad
  getKaiAd({
    publisher: 'bc247e7b-cd8a-4dda-be8c-e766a729f6b8',
    app: 'Did you know',
    slot: 'dykFirstOpenFS',
    onerror: err => console.error(err),
    onready: ad => {
      ad.call('display');
    }
  });

  // Banner ad
  getKaiAd({
    publisher: 'bc247e7b-cd8a-4dda-be8c-e766a729f6b8',
    app: 'Did you know',
    slot: 'dykBannerAD',

    h: 54,
    w: 240,
    test: 0,
    // default timeout is 1min
    // timeout: 10*1000,
    container: document.getElementById('ad-container'),

    onerror: err => console.error('Custom catch:', err),
    onready: ad => {
      loadAdContainer();

      // Ad is ready to be displayed
      // calling 'display' will display the ad
      ad.call('display', {
        // navClass is needed
        // class name must be unique to call click() function using it
        navClass: 'ad-class',
        display: 'block'
      });
    }
  });
});
