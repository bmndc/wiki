const _fps = 12;
let _cellSize;
let _maps;
let _view = "menu";
let _game;
let _logo;

function preload() {
  _maps = getMaps();
  _logo = loadImage("assets/logo.png");
  _instructions = loadImage("assets/instructions.png");
}

function setup() {
  frameRate(_fps);
  const gameWidth = document.getElementById("game").clientWidth;
  const gameHeight = document.getElementById("game").clientHeight;
  const canvas = createCanvas(gameWidth, gameHeight);
  canvas.parent("game");
  _width = windowWidth;
  _height = windowHeight;

  // make height and width the same. take the smallest length
  if (gameWidth > windowHeight) {
    _width = gameHeight;
    _height = gameHeight;
  } else {
    _width = gameWidth;
    _height = gameWidth;
  }
  _unitSize = _width / 10;
  noStroke();
  ellipseMode(CENTER);
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function start7x7() {
  _cellSize = _width / 7.6;
  const maps = shuffle(_maps["easy7"]);
  const map = maps[0].trim().split("\n");
  _game = new Game(map, _cellSize);
  _view = "playing";
}

function start10x10() {
  _cellSize = _width / 10.6;
  const maps = shuffle(_maps["easy10"]);
  const map = maps[0].trim().split("\n");
  _game = new Game(map, _cellSize);
  _view = "playing";
}

function draw() {
  background("#fff");
  if (_view === "menu") {
    showMenu();
  } else if(_view === "instructions") {
    showInstructions();
  } else if (_game && _view === "playing") {
    push();
    strokeWeight(_unitSize * .05);
    stroke("#FF9671");
    noFill();
    rect(_cellSize * .1, _cellSize * .7, _cellSize * (_game.size + 1) - _cellSize * .6,  _cellSize * (_game.size + 1) - _cellSize * .6) // buitenkader
    drawBoard();
    pop();
    if (_game && _game.gameState === "won") {
      showWon();
    }
  }
  showMenuBar();
}

function drawBoard() {
  translate(_cellSize * .3, _cellSize * .9);
  stroke("#b99154");
  strokeWeight(_cellSize * .08);
  noFill();
  rect(_game.focused.x * _cellSize + _cellSize * .15, _game.focused.y * _cellSize + _cellSize * .15, _cellSize * .7, _cellSize * .7);
  noStroke();

  textSize(_cellSize * .5);

  for (let y=0;y<=_game.size;y++) {
    for (let x=0;x<=_game.size;x++) {
      if (x < _game.size) {
        const hvalue = _game.puzzle[y * 2][x * 2 + 1];
        let color1 = "#2C73D2";
        let color2 = "#ADC5CF";
        if (_game.gameState === "checking") {
          if (_game.isError(x * 2 + 1, y * 2)) {
            color1 = "#D13A28";
            color2 = "#D13A28";
          } else {
            color1 = "#00C9A7";
            color2 = "#00C9A7";
          }
        }
        if (hvalue === "*") {
          fill(color1);
          rect(_cellSize * x, _cellSize * y - _cellSize * .05, _cellSize, _cellSize * .1);
        } else if (hvalue === "x") {
          fill(color2);
          rect(_cellSize * x + _cellSize * .4, _cellSize * y - _cellSize * .05, _cellSize * .2, _cellSize * .1);
        }
      }
      if (y < _game.size) {
        const vvalue = _game.puzzle[y * 2 + 1][x * 2];
        let color3 = "#2C73D2";
        let color4 = "#ADC5CF";
        if (_game.gameState === "checking") {
          if (_game.isError(x * 2, y * 2 + 1)) {
            color3 = "#D13A28";
            color4 = "#D13A28";
          } else {
            color3 = "#00C9A7";
            color4 = "#00C9A7";
          }
        }
        if (vvalue === "*") {
          fill(color3);
          rect(_cellSize * x - _cellSize * .05, _cellSize * y, _cellSize * .1, _cellSize);
        } else if (vvalue === "x") {
          fill(color4);
          rect(_cellSize * x - _cellSize * .05, _cellSize * y + _cellSize * .4, _cellSize * .1, _cellSize * .2);
        }
      }
      fill("#2C73D2");
      if (y < _game.size && x < _game.size) {
        const nvalue = _game.puzzle[y * 2 + 1][x * 2 + 1];
        if (nvalue !== "o") {
          text(nvalue, _cellSize * x + _cellSize * .5, _cellSize * y + _cellSize * .52);
        }
      }
      fill("#4B4453");
      ellipse(_cellSize * x, _cellSize * y, _cellSize * .15, _cellSize * .15);
    }
  }
}

function keyPressed() {
  if (key === "SoftLeft") {
    if (_ad) {
      _ad.call("click");
    }
  }
  if ((key === "SoftRight" || key === "r") && (_game && (_game.gameState === "playing" || _game.gameState === "checking"))) {
    if (_view !== "menu") {
      _view = "menu";
    } else {
      _view = "playing";
    }
  }

  if (_game && _game.gameState === "won" && key === "1") {
    _game = null;
    _view = "menu";
    return;
  }

  if (_view === "instructions") {
    if (key === "SoftRight" || key === "r") {
      _view = "menu";
      return;
    }
  }

  if (_view === "menu") {
    if (key === "1") {
      start7x7();
    }
    if (key === "2") {
      start10x10();
    }
    if (key === "5") {
      _view = "instructions";
    }
    if (key === "7" && _game) {
      _game.gameState = "checking";
      _view = "playing";
    }
    if (key === "9" && _game) {
      _game.resetPuzzle();
      _view = "playing";
    }
    if (key === "#" && _game) {
      _game.solve();
      _view = "playing";
    }
    return;
  }
  if (key === "ArrowLeft") {
    _game.setFocus(_game.focused.x - 1, _game.focused.y);
  }
  if (key === "ArrowRight") {
    _game.setFocus(_game.focused.x + 1, _game.focused.y);
  }
  if (key === "ArrowDown") {
    _game.setFocus(_game.focused.x, _game.focused.y + 1);
  }
  if (key === "ArrowUp") {
    _game.setFocus(_game.focused.x, _game.focused.y - 1);
  }
  if (key === "2") {
    _game.toggleCell("top");
  }
  if (key === "6") {
    _game.toggleCell("right");
  }
  if (key === "8") {
    _game.toggleCell("bottom");
  }
  if (key === "4") {
    _game.toggleCell("left");
  }
}
