class Game {
  // * = wall, x = empty, ? = not filled in
  constructor(mapLines, cellSize) {
    this.size = (mapLines.length - 1) / 2;
    this.solution = mapLines;
    this.setFocus(4, 4);
    this.resetPuzzle();
    this.gameState = "playing";
  }

  resetPuzzle() {
    this.puzzle = [];
    for (let i in this.solution) this.puzzle.push(replaceAll(replaceAll(this.solution[i], "*", "?"), "x", "?"));
  }

  solve() {
    this.puzzle = [];
    for (let l of this.solution) this.puzzle.push(l);
  }

  toggleCell(direction) {
    let x = this.focused.x * 2 + 1;
    let y = this.focused.y * 2 + 1;
    if (direction === "right") x++;
    if (direction === "left") x--;
    if (direction === "top") y--;
    if (direction === "bottom") y++;
    this.gameState = "playing";
    const v = this.puzzle[y][x];
    if (v === "*") {
      this.setPuzzleCell(x, y, "x");
    } else if (v === "x") {
      this.setPuzzleCell(x, y, "?");
    } else {
      this.setPuzzleCell(x, y, "*");
    }
  }

  setPuzzleCell(x, y, value) {
    this.puzzle[y] = this.puzzle[y].substring(0, x) + value + this.puzzle[y].substring(x + 1);
    if (this.hasWon()) {
      this.gameState = "won";
    }
  }

  isError(x, y) {
    return _game.puzzle[y][x] !== "?" && _game.puzzle[y][x] !== _game.solution[y][x];
  }

  hasWon() {
    for(let y=0;y<this.size;y++) {
      for(let x=0;x<this.size;x++) {
        if (_game.solution[y * 2][x * 2 + 1] === "*" && _game.puzzle[y * 2][x * 2 + 1] !== "*") return false;
        if (_game.solution[y * 2][x * 2 + 1] === "x" && _game.puzzle[y * 2][x * 2 + 1] === "*") return false;
        if (_game.solution[y * 2 + 1][x * 2] === "*" && _game.puzzle[y * 2 + 1][x * 2] !== "*") return false;
        if (_game.solution[y * 2 + 1][x * 2] === "x" && _game.puzzle[y * 2 + 1][x * 2] === "*") return false;
      }
    }
    return true;
  }

  setFocus(x, y) {
    if (x < 0) x = this.size - 1;
    if (x > this.size - 1) x = 0;
    if (y < 0) y = this.size - 1;
    if (y > this.size - 1) y = 0;
    this.focused = new XY(x, y);
    this.gameState = "playing";
  }
}

function shuffle(a) {
  return a => a.sort(() => 0.5 - Math.random());
}

function replaceAll(string, search, replace) {
  return string.split(search).join(replace);
}
