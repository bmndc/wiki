class Cell {
  constructor () {
  }
}

class XY {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
}
