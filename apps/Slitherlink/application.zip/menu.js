function showMenu() {
  push();
  textAlign(CENTER, CENTER);
  fill("#252525");
  textSize(_unitSize);
  image(_logo,[sx=width / 2 - _unitSize],[sy=_unitSize * .8],[sWidth=_unitSize * 2],[sHeight=_unitSize * 2]);
  text("Slitherlink Menu", width / 2, _unitSize * 3.5);
  textSize(_unitSize * .8);
  text("1. New 7x7 game", width / 2, _unitSize * 5);
  text("2. New 10x10 game", width / 2, _unitSize * 6);
  text("5. Instructions", width / 2, _unitSize * 7);
  if (_game && (_game.gameState === "playing" || _game.gameState === "checking")) {
    text("7. Check Puzzle", width / 2, _unitSize * 8);
    text("9. Clear Puzzle", width / 2, _unitSize * 9);
  }
  pop();
}

function showInstructions() {
  image(_instructions,[sx=0],[sy=0],[sWidth=_unitSize * 8.5],[sHeight=_unitSize * 10]);
}

function showMenuBar() {
  push();
  textSize(_unitSize * .6);
  fill("#252525");
  if (_ad) {
    text("ad", _unitSize * .5, height - _unitSize * .3);
  }
  if (_game && (_game.gameState === "playing" || _game.gameState === "checking")) {
    if (_view === "playing") {
      text("menu", width - _unitSize * .9, height - _unitSize * .3);
    } else if (_view === "menu") {
      text("back", width - _unitSize * .8, height - _unitSize * .3);
    }
  }
  if (_view === "instructions") {
    text("back", width - _unitSize * .8, height - _unitSize * .3);
  }
  pop();
}

function showWon() {
  push();
  translate(_unitSize * 2, _unitSize * 3.5);
  strokeWeight(0);
  fill("#333");
  rect(_unitSize * .2, _unitSize * .2, _unitSize * 6, _unitSize * 2);
  strokeWeight(4);
  stroke("#000");
  fill("#eee");
  textSize(_unitSize * .7);
  rect(0, 0, _unitSize * 6, _unitSize * 2);
  fill("#000");
  noStroke();
  text("Puzzle solved\n1. Menu", _unitSize * 2.8, _unitSize * 1);
  pop();
}
