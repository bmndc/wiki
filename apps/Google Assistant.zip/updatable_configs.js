


PlatformConfigs.SUPPORTED_LOCALES = ['de', 'en-AU', 'en-CA', 'en-GB', 'en-IN', 'en-SG', 'en-US', 'es', 'es-MX', 'es-US', 'fr', 'fr-CA', 'hi', 'id', 'it', 'pt-BR', 'th', 'bn', 'mr', 'ta', 'te'];


PlatformConfigs.CORE_APP_VERSION = PlatformConfigs.APP_VERSION;
