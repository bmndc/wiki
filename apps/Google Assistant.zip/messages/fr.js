opa.Messages['fr'] = {
  "ACTION_TEXT_RESPONSE_NO_CONTACTS": {
    "message": "Aucun contact trouv\u00e9."
  },
  "ACTION_TEXT_RESPONSE_OK": {
    "message": "OK"
  },
  "ACTION_VOCAL_RESPONSE_NO_CONTACTS": {
    "message": "Aucun contact trouv\u00e9."
  },
  "ACTION_VOCAL_RESPONSE_OK": {
    "message": "OK"
  },
  "ACTION_VOCAL_RESPONSE_SENDING_MESSAGE": {
    "message": "Envoi du message en cours"
  },
  "ACTION_VOCAL_RESPONSE_SMS_TIMEOUT": {
    "message": "L'envoi de votre message prend plus de temps que d'habitude. R\u00e9essayez dans quelques minutes."
  },
  "APP_NOT_FOUND_ERROR": {
    "message": "Je n'ai pas trouv\u00e9 cette application."
  },
  "BUTTON_ACCEPT": {
    "message": "Accepter"
  },
  "BUTTON_AGREE": {
    "message": "Accepter"
  },
  "BUTTON_ALLOW": {
    "message": "Autoriser"
  },
  "BUTTON_BACK": {
    "message": "Retour"
  },
  "BUTTON_CANCEL": {
    "message": "Annuler"
  },
  "BUTTON_DENY": {
    "message": "Non, merci"
  },
  "BUTTON_EXIT": {
    "message": "Quitter"
  },
  "BUTTON_EXPLORE": {
    "message": "D\u00e9couvrir"
  },
  "BUTTON_GOOGLE_DOT_COM": {
    "message": "Google.com"
  },
  "BUTTON_HOME": {
    "message": "Accueil"
  },
  "BUTTON_NEXT": {
    "message": "Suivant"
  },
  "BUTTON_OK": {
    "message": "OK"
  },
  "BUTTON_OPEN": {
    "message": "Ouvrir"
  },
  "BUTTON_REFRESH": {
    "message": "Actualiser"
  },
  "BUTTON_SEARCH": {
    "message": "Rechercher"
  },
  "BUTTON_SEARCH_ON_GOOGLE": {
    "message": "Chercher sur Google"
  },
  "BUTTON_SEE_MORE": {
    "message": "Plus de r\u00e9sultats"
  },
  "BUTTON_SELECT": {
    "message": "S\u00e9lectionner"
  },
  "BUTTON_SHOW_MORE": {
    "message": "Afficher plus\u2026"
  },
  "BUTTON_TRY": {
    "message": "Aide"
  },
  "BUTTON_UDC_SCROLL": {
    "message": "Faire d\u00e9filer l'\u00e9cran"
  },
  "CONTACTS_CONSENT_BODY": {
    "message": "Pour savoir qui vous voulez appeler ou \u00e0 qui vous voulez envoyer un SMS, l'Assistant\u00a0Google a besoin de votre autorisation pour transmettre vos contacts \u00e0 Google chaque fois que vous lui parlez."
  },
  "CONTACTS_CONSENT_BODY_V02": {
    "message": "Pour savoir qui vous voulez appeler ou \u00e0 qui vous voulez envoyer un SMS, l'Assistant a besoin de votre autorisation pour stocker vos contacts aupr\u00e8s de Google de mani\u00e8re temporaire."
  },
  "CONTACTS_CONSENT_TITLE": {
    "message": "Autoriser l'Assistant\u00a0Google \u00e0 acc\u00e9der \u00e0 vos contacts"
  },
  "CONTACTS_CONSENT_TITLE_FOR_REACCEPT": {
    "message": "Pour une exp\u00e9rience optimale, souhaitez-vous autoriser l'Assistant\u00a0Google \u00e0 acc\u00e9der \u00e0 vos contacts\u00a0?"
  },
  "CONVERSATION_STARTER_CALL": {
    "message": "Passe un appel t\u00e9l\u00e9phonique"
  },
  "CONVERSATION_STARTER_FIND_RESTAURANTS": {
    "message": "Trouve-moi des restaurants \u00e0 proximit\u00e9"
  },
  "CONVERSATION_STARTER_JOKE": {
    "message": "Raconte-moi une blague"
  },
  "CONVERSATION_STARTER_MESSAGE": {
    "message": "Envoie un message"
  },
  "CONVERSATION_STARTER_OPEN_APP": {
    "message": "Ouvre l'appareil photo"
  },
  "CONVERSATION_STARTER_PLAY_SONGS": {
    "message": "Mets des titres de Bollywood"
  },
  "CONVERSATION_STARTER_YOUTUBE": {
    "message": "Lance YouTube"
  },
  "ENDPOINT_TYPE_HOME": {
    "message": "personnel"
  },
  "ENDPOINT_TYPE_MAIN": {
    "message": "principal"
  },
  "ENDPOINT_TYPE_MOBILE": {
    "message": "mobile"
  },
  "ENDPOINT_TYPE_OTHER": {
    "message": "autre"
  },
  "ENDPOINT_TYPE_WORK": {
    "message": "professionnel"
  },
  "EXPLORE_FAILURE_ERROR": {
    "message": "Une erreur s'est produite. Veuillez r\u00e9essayer."
  },
  "FAIL_UPDATE_BLUETOOTH": {
    "message": "\u00c9chec de la mise \u00e0 jour du Bluetooth. Veuillez activer ce dernier manuellement depuis les param\u00e8tres."
  },
  "FAIL_UPDATE_FLASHLIGHT": {
    "message": "\u00c9chec de la mise \u00e0 jour de la lampe de poche. Veuillez activer cette derni\u00e8re manuellement."
  },
  "FAIL_UPDATE_GEOLOCATION": {
    "message": "\u00c9chec de la mise \u00e0 jour de la g\u00e9olocalisation. Veuillez activer cette derni\u00e8re manuellement depuis les param\u00e8tres."
  },
  "FETCHING_ACCOUNT_STATUS": {
    "message": "Recherche de la connexion\u2026"
  },
  "INITIAL_PROMPT_MIC": {
    "message": "Appuyez sur $MICROPHONE$ pour parler",
    "placeholders": {
      "MICROPHONE": {
        "content": "$1"
      }
    }
  },
  "LISTENING": {
    "message": "Je vous \u00e9coute\u2026"
  },
  "LOCATION_CONSENT_BODY": {
    "message": "Pour vous fournir des r\u00e9sultats locaux (comme les restaurants \u00e0 proximit\u00e9), l'Assistant\u00a0Google a besoin de votre autorisation pour transmettre votre position \u00e0 Google chaque fois que vous lui parlez."
  },
  "LOCATION_CONSENT_TITLE": {
    "message": "Autoriser l'Assistant\u00a0Google \u00e0 acc\u00e9der \u00e0 votre position"
  },
  "LOCATION_CONSENT_TITLE_FOR_REACCEPT": {
    "message": "Pour une exp\u00e9rience plus personnalis\u00e9e, souhaitez-vous autoriser l'Assistant\u00a0Google \u00e0 acc\u00e9der \u00e0 votre position\u00a0?"
  },
  "MY_ACCOUNT": {
    "message": "Mon compte"
  },
  "MY_ACCOUNT_BODY": {
    "message": "La fonctionnalit\u00e9 Mon compte n'est pas compatible avec cet appareil pour le moment. Pour consulter ou modifier vos informations de compte, rendez-vous sur https://myaccount.google.com/ sur un appareil compatible."
  },
  "MY_ACCOUNT_TITLE": {
    "message": "Mon compte"
  },
  "NETWORK_ERROR": {
    "message": "Impossible de se connecter \u00e0 Internet. Veuillez v\u00e9rifier votre connexion et r\u00e9essayer."
  },
  "OPEN_APP_SUCCESS": {
    "message": "Ouverture de l'application."
  },
  "PLAYER_TITLE_NEWS": {
    "message": "ACTUALIT\u00c9S"
  },
  "PLAYER_TITLE_PLACEHOLDER": {
    "message": "Media Player"
  },
  "PUNT_FEATURE_NOT_SUPPORTED": {
    "message": "Malheureusement, je ne peux pas effectuer cette op\u00e9ration sur cet appareil. Mais vous pouvez me demander autre chose."
  },
  "SERVER_ERROR": {
    "message": "Nous rencontrons actuellement des probl\u00e8mes techniques. Veuillez r\u00e9essayer dans quelques minutes."
  },
  "SETTINGS_LANGUAGE_TITLE": {
    "message": "Dans quelle langue pr\u00e9f\u00e9rez-vous parler\u00a0?"
  },
  "SETTINGS_OPTION_CHANGE_CONTACTS_PERMISSION": {
    "message": "Autorisation d'acc\u00e9der aux contacts"
  },
  "SETTINGS_OPTION_CHANGE_LANGUAGE": {
    "message": "Changer de langue"
  },
  "SETTINGS_OPTION_CHANGE_LOCATION_PERMISSION": {
    "message": "Autorisation d'acc\u00e9der \u00e0 la position"
  },
  "SETTINGS_OPTION_CLEAR_DATA": {
    "message": "Effacer les informations sur l'utilisateur"
  },
  "SETTINGS_OPTION_PRIVACY_POLICY": {
    "message": "R\u00e8gles de confidentialit\u00e9"
  },
  "SETTINGS_OPTION_TERMS_OF_SERVICE": {
    "message": "Conditions d'utilisation"
  },
  "SETTINGS_PROMPT": {
    "message": "Appuyez sur $KEY$ pour acc\u00e9der aux param\u00e8tres",
    "placeholders": {
      "KEY": {
        "content": "$1"
      }
    }
  },
  "SETTINGS_TITLE": {
    "message": "Param\u00e8tres"
  },
  "SETTINGS_VERSION": {
    "message": "Version\u00a0:"
  },
  "SIGNIN": {
    "message": "Se connecter"
  },
  "SIGNOUT": {
    "message": "Se d\u00e9connecter"
  },
  "SNACKBAR_BLUETOOTH_DISABLED": {
    "message": "Bluetooth d\u00e9sactiv\u00e9."
  },
  "SNACKBAR_BLUETOOTH_ENABLED": {
    "message": "Bluetooth activ\u00e9."
  },
  "SNACKBAR_HISTORY_CLEARED": {
    "message": "Votre historique a bien \u00e9t\u00e9 effac\u00e9."
  },
  "SNACKBAR_LANGUAGE_PREFERENCE_SAVED": {
    "message": "Langue enregistr\u00e9e."
  },
  "SNACKBAR_NOINPUT_HELP": {
    "message": "Je n'ai pas compris. Veuillez r\u00e9p\u00e9ter."
  },
  "SNACKBAR_PERMISSION_SAVED": {
    "message": "Autorisation enregistr\u00e9e."
  },
  "SUGGESTIONS_PROMPT_MIC": {
    "message": "Appuyez sur\u00a0$MICROPHONE$ et dites\u2026",
    "placeholders": {
      "MICROPHONE": {
        "content": "$1"
      }
    }
  },
  "SUGGESTION_ANSWER": {
    "message": "\"Quel temps fait-il\u00a0?\""
  },
  "SUGGESTION_BLUETOOTH": {
    "message": "\"Active le Bluetooth\""
  },
  "SUGGESTION_CALL": {
    "message": "\"Appelle Sophie\""
  },
  "SUGGESTION_CALL_EN_IN": {
    "message": "\"Appelle Anne\""
  },
  "SUGGESTION_PICTURES": {
    "message": "\"Montre-moi des photos de Beyonc\u00e9\""
  },
  "SUGGESTION_PICTURES_EN_IN": {
    "message": "\"Montre-moi des photos de Shahrukh\u00a0Khan\""
  },
  "SUGGESTION_SMS": {
    "message": "\"Envoie un message \u00e0 Jean\""
  },
  "SUGGESTION_SMS_EN_IN": {
    "message": "\"Envoie un message \u00e0 Akshay\""
  },
  "SUGGESTION_YOUTUBE": {
    "message": "\"Mets Lady\u00a0Gaga sur YouTube\""
  },
  "SUGGESTION_YOUTUBE_EN_IN": {
    "message": "\"Mets Kala\u00a0Chashma sur YouTube\""
  },
  "TERMS_AND_CONDITIONS_BODY_PRIVACY": {
    "message": "Appuyez sur \"2\" pour lire les r\u00e8gles de confidentialit\u00e9\u00a0:"
  },
  "TERMS_AND_CONDITIONS_BODY_TERMS": {
    "message": "Appuyez sur \"1\" pour lire les conditions d'utilisation\u00a0:"
  },
  "TERMS_AND_CONDITIONS_TITLE": {
    "message": "Veuillez lire les conditions d'utilisation et les r\u00e8gles de confidentialit\u00e9 de Google"
  },
  "UDC_SETTINGS_LEARN_MORE_PROMPT": {
    "message": "Appuyez sur $INDEX$ pour en savoir plus",
    "placeholders": {
      "INDEX": {
        "content": "$1"
      }
    }
  },
  "UNKNOWN_CONNECTION_ERROR": {
    "message": "Nous rencontrons actuellement des probl\u00e8mes techniques."
  },
  "VERSION_EXPIRED_ERROR": {
    "message": "L'application est obsol\u00e8te. Veuillez contacter votre fournisseur pour installer la derni\u00e8re version disponible."
  }
};
