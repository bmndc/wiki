opa.Messages['it'] = {
  "ACTION_TEXT_RESPONSE_NO_CONTACTS": {
    "message": "Nessun contatto trovato."
  },
  "ACTION_TEXT_RESPONSE_OK": {
    "message": "OK"
  },
  "ACTION_VOCAL_RESPONSE_NO_CONTACTS": {
    "message": "Nessun contatto trovato."
  },
  "ACTION_VOCAL_RESPONSE_OK": {
    "message": "OK"
  },
  "ACTION_VOCAL_RESPONSE_SENDING_MESSAGE": {
    "message": "Sto inviando il messaggio."
  },
  "ACTION_VOCAL_RESPONSE_SMS_TIMEOUT": {
    "message": "L'invio del messaggio sta richiedendo pi\u00f9 tempo del solito. Riprova tra qualche minuto."
  },
  "APP_NOT_FOUND_ERROR": {
    "message": "Non sono riuscito a trovare l'app."
  },
  "BUTTON_ACCEPT": {
    "message": "Accetta"
  },
  "BUTTON_AGREE": {
    "message": "Accetto"
  },
  "BUTTON_ALLOW": {
    "message": "Consenti"
  },
  "BUTTON_BACK": {
    "message": "Indietro"
  },
  "BUTTON_CANCEL": {
    "message": "Annulla"
  },
  "BUTTON_DENY": {
    "message": "No, grazie"
  },
  "BUTTON_EXIT": {
    "message": "Esci"
  },
  "BUTTON_EXPLORE": {
    "message": "Esplora"
  },
  "BUTTON_GOOGLE_DOT_COM": {
    "message": "Google.com"
  },
  "BUTTON_HOME": {
    "message": "Home"
  },
  "BUTTON_NEXT": {
    "message": "Avanti"
  },
  "BUTTON_OK": {
    "message": "OK"
  },
  "BUTTON_OPEN": {
    "message": "Apri"
  },
  "BUTTON_REFRESH": {
    "message": "Aggiorna"
  },
  "BUTTON_SEARCH": {
    "message": "Cerca"
  },
  "BUTTON_SEARCH_ON_GOOGLE": {
    "message": "Cerca su Google"
  },
  "BUTTON_SEE_MORE": {
    "message": "Altro"
  },
  "BUTTON_SELECT": {
    "message": "Seleziona"
  },
  "BUTTON_SHOW_MORE": {
    "message": "Mostra altri\u2026"
  },
  "BUTTON_TRY": {
    "message": "Guida"
  },
  "BUTTON_UDC_SCROLL": {
    "message": "Scorri"
  },
  "CONTACTS_CONSENT_BODY": {
    "message": "Affinch\u00e9 l'assistente possa capire chi vuoi chiamare o a chi vuoi inviare un messaggio, devi concedere l'autorizzazione a inviare i tuoi contatti a Google ogni volta che gli parli."
  },
  "CONTACTS_CONSENT_BODY_V02": {
    "message": "Affinch\u00e9 l'assistente possa capire chi vuoi chiamare o a chi vuoi inviare un messaggio, devi concedergli l'autorizzazione a memorizzare temporaneamente i tuoi contatti con Google."
  },
  "CONTACTS_CONSENT_TITLE": {
    "message": "Consenti all'Assistente Google di accedere ai tuoi contatti"
  },
  "CONTACTS_CONSENT_TITLE_FOR_REACCEPT": {
    "message": "Per avere un'esperienza ancora migliore, permetteresti all'Assistente Google di accedere ai tuoi contatti?"
  },
  "CONVERSATION_STARTER_CALL": {
    "message": "Fai una telefonata"
  },
  "CONVERSATION_STARTER_FIND_RESTAURANTS": {
    "message": "Trova ristoranti nella mia zona"
  },
  "CONVERSATION_STARTER_JOKE": {
    "message": "Raccontami una barzelletta"
  },
  "CONVERSATION_STARTER_MESSAGE": {
    "message": "Invia un messaggio"
  },
  "CONVERSATION_STARTER_OPEN_APP": {
    "message": "Apri la fotocamera"
  },
  "CONVERSATION_STARTER_PLAY_SONGS": {
    "message": "Fammi ascoltare canzoni di Bollywood"
  },
  "CONVERSATION_STARTER_YOUTUBE": {
    "message": "Apri YouTube"
  },
  "ENDPOINT_TYPE_HOME": {
    "message": "casa"
  },
  "ENDPOINT_TYPE_MAIN": {
    "message": "principale"
  },
  "ENDPOINT_TYPE_MOBILE": {
    "message": "cellulare"
  },
  "ENDPOINT_TYPE_OTHER": {
    "message": "altro"
  },
  "ENDPOINT_TYPE_WORK": {
    "message": "lavoro"
  },
  "EXPLORE_FAILURE_ERROR": {
    "message": "Si \u00e8 verificato un problema. Riprova."
  },
  "FAIL_UPDATE_BLUETOOTH": {
    "message": "Aggiornamento Bluetooth non riuscito. Attivalo manualmente dalle Impostazioni."
  },
  "FAIL_UPDATE_FLASHLIGHT": {
    "message": "Impossibile aggiornare l'impostazione della torcia; attivala manualmente."
  },
  "FAIL_UPDATE_GEOLOCATION": {
    "message": "Aggiornamento della geolocalizzazione non riuscito. Attivalo manualmente dalle Impostazioni."
  },
  "FETCHING_ACCOUNT_STATUS": {
    "message": "Verifica dell'account per l'accesso\u2026"
  },
  "INITIAL_PROMPT_MIC": {
    "message": "Premi $MICROPHONE$ per parlare",
    "placeholders": {
      "MICROPHONE": {
        "content": "$1"
      }
    }
  },
  "LISTENING": {
    "message": "In ascolto\u2026"
  },
  "LOCATION_CONSENT_BODY": {
    "message": "Per ricevere risultati locali, ad esempio ristoranti nella tua zona, devi autorizzare l'assistente a inviare la tua posizione a Google ogni volta che gli parli."
  },
  "LOCATION_CONSENT_TITLE": {
    "message": "Consenti all'Assistente Google di accedere alla tua posizione"
  },
  "LOCATION_CONSENT_TITLE_FOR_REACCEPT": {
    "message": "Per avere un'esperienza pi\u00f9 personalizzata, consentiresti all'Assistente Google di accedere alla tua posizione?"
  },
  "MY_ACCOUNT": {
    "message": "Account personale"
  },
  "MY_ACCOUNT_BODY": {
    "message": "La funzionalit\u00e0 Account personale non \u00e8 attualmente supportata su questo dispositivo. Per visualizzare o aggiornare i dati del tuo account, visita la pagina https://myaccount.google.com/ da un dispositivo compatibile."
  },
  "MY_ACCOUNT_TITLE": {
    "message": "Account personale"
  },
  "NETWORK_ERROR": {
    "message": "Impossibile connettersi a Internet. Controlla la connessione e riprova."
  },
  "OPEN_APP_SUCCESS": {
    "message": "Sto aprendo l'app."
  },
  "PLAYER_TITLE_NEWS": {
    "message": "NOTIZIE"
  },
  "PLAYER_TITLE_PLACEHOLDER": {
    "message": "Media Player"
  },
  "PUNT_FEATURE_NOT_SUPPORTED": {
    "message": "Mi spiace, non posso farlo su questo dispositivo. Prova a chiedere qualcos'altro."
  },
  "SERVER_ERROR": {
    "message": "Si sono verificati problemi tecnici. Riprova tra un paio di minuti."
  },
  "SETTINGS_LANGUAGE_TITLE": {
    "message": "In che lingua preferisci parlare?"
  },
  "SETTINGS_OPTION_CHANGE_CONTACTS_PERMISSION": {
    "message": "Autorizzazione per i contatti"
  },
  "SETTINGS_OPTION_CHANGE_LANGUAGE": {
    "message": "Cambia lingua"
  },
  "SETTINGS_OPTION_CHANGE_LOCATION_PERMISSION": {
    "message": "Autorizzazione di accesso alla posizione"
  },
  "SETTINGS_OPTION_CLEAR_DATA": {
    "message": "Cancella dati dell'utente"
  },
  "SETTINGS_OPTION_PRIVACY_POLICY": {
    "message": "Norme sulla privacy"
  },
  "SETTINGS_OPTION_TERMS_OF_SERVICE": {
    "message": "Termini di servizio"
  },
  "SETTINGS_PROMPT": {
    "message": "Premi $KEY$ per accedere alle Impostazioni",
    "placeholders": {
      "KEY": {
        "content": "$1"
      }
    }
  },
  "SETTINGS_TITLE": {
    "message": "Impostazioni"
  },
  "SETTINGS_VERSION": {
    "message": "Versione:"
  },
  "SIGNIN": {
    "message": "Accedi"
  },
  "SIGNOUT": {
    "message": "Esci"
  },
  "SNACKBAR_BLUETOOTH_DISABLED": {
    "message": "Bluetooth disattivato."
  },
  "SNACKBAR_BLUETOOTH_ENABLED": {
    "message": "Bluetooth attivato."
  },
  "SNACKBAR_HISTORY_CLEARED": {
    "message": "La cronologia \u00e8 stata cancellata."
  },
  "SNACKBAR_LANGUAGE_PREFERENCE_SAVED": {
    "message": "Preferenza della lingua salvata."
  },
  "SNACKBAR_NOINPUT_HELP": {
    "message": "Non ho capito. Prova a ripetere."
  },
  "SNACKBAR_PERMISSION_SAVED": {
    "message": "Autorizzazione salvata."
  },
  "SUGGESTIONS_PROMPT_MIC": {
    "message": "Premi $MICROPHONE$ e prova a dire\u2026",
    "placeholders": {
      "MICROPHONE": {
        "content": "$1"
      }
    }
  },
  "SUGGESTION_ANSWER": {
    "message": "\"Che tempo fa?\""
  },
  "SUGGESTION_BLUETOOTH": {
    "message": "\"Attiva Bluetooth\""
  },
  "SUGGESTION_CALL": {
    "message": "\"Chiama Sofia\""
  },
  "SUGGESTION_CALL_EN_IN": {
    "message": "\"Chiama Anjali\""
  },
  "SUGGESTION_PICTURES": {
    "message": "\"Mostrami foto di Beyonc\u00e9\""
  },
  "SUGGESTION_PICTURES_EN_IN": {
    "message": "\"Mostrami foto di Shah Rukh Khan\""
  },
  "SUGGESTION_SMS": {
    "message": "\"Invia un messaggio a Mario\""
  },
  "SUGGESTION_SMS_EN_IN": {
    "message": "\"Invia un messaggio ad Akshay\""
  },
  "SUGGESTION_YOUTUBE": {
    "message": "\"Metti Lady Gaga su YouTube\""
  },
  "SUGGESTION_YOUTUBE_EN_IN": {
    "message": "\"Fammi ascoltare Kala Chashma su YouTube\""
  },
  "TERMS_AND_CONDITIONS_BODY_PRIVACY": {
    "message": "Premi 2 per leggere le Norme sulla privacy:"
  },
  "TERMS_AND_CONDITIONS_BODY_TERMS": {
    "message": "Premi 1 per leggere i Termini di servizio:"
  },
  "TERMS_AND_CONDITIONS_TITLE": {
    "message": "Leggi i Termini di servizio e le Norme sulla privacy di Google"
  },
  "UDC_SETTINGS_LEARN_MORE_PROMPT": {
    "message": "Premi $INDEX$ per ulteriori informazioni",
    "placeholders": {
      "INDEX": {
        "content": "$1"
      }
    }
  },
  "UNKNOWN_CONNECTION_ERROR": {
    "message": "Si sono verificati problemi tecnici."
  },
  "VERSION_EXPIRED_ERROR": {
    "message": "L'applicazione non \u00e8 aggiornata. Contatta il provider per aggiornarla all'ultima versione."
  }
};
