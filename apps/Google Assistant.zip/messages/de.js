opa.Messages['de'] = {
  "ACTION_TEXT_RESPONSE_NO_CONTACTS": {
    "message": "Keine Kontakte gefunden"
  },
  "ACTION_TEXT_RESPONSE_OK": {
    "message": "Ok"
  },
  "ACTION_VOCAL_RESPONSE_NO_CONTACTS": {
    "message": "Keine Kontakte gefunden"
  },
  "ACTION_VOCAL_RESPONSE_OK": {
    "message": "Ok"
  },
  "ACTION_VOCAL_RESPONSE_SENDING_MESSAGE": {
    "message": "Die Nachricht wird gesendet."
  },
  "ACTION_VOCAL_RESPONSE_SMS_TIMEOUT": {
    "message": "Das Versenden deiner Nachricht dauert l\u00e4nger als \u00fcblich. Versuch es in ein paar Minuten noch mal."
  },
  "APP_NOT_FOUND_ERROR": {
    "message": "Ich kann diese App nicht finden."
  },
  "BUTTON_ACCEPT": {
    "message": "Ok"
  },
  "BUTTON_AGREE": {
    "message": "Zustimmen"
  },
  "BUTTON_ALLOW": {
    "message": "Zulassen"
  },
  "BUTTON_BACK": {
    "message": "Zur\u00fcck"
  },
  "BUTTON_CANCEL": {
    "message": "Abbrechen"
  },
  "BUTTON_DENY": {
    "message": "Nein danke"
  },
  "BUTTON_EXIT": {
    "message": "Beenden"
  },
  "BUTTON_EXPLORE": {
    "message": "Erkunden"
  },
  "BUTTON_GOOGLE_DOT_COM": {
    "message": "Google.com"
  },
  "BUTTON_HOME": {
    "message": "Startbildschirm"
  },
  "BUTTON_NEXT": {
    "message": "Weiter"
  },
  "BUTTON_OK": {
    "message": "Ok"
  },
  "BUTTON_OPEN": {
    "message": "\u00d6ffnen"
  },
  "BUTTON_REFRESH": {
    "message": "Aktualisieren"
  },
  "BUTTON_SEARCH": {
    "message": "Zur Google-Suche"
  },
  "BUTTON_SEARCH_ON_GOOGLE": {
    "message": "Zur Google-Suche"
  },
  "BUTTON_SEE_MORE": {
    "message": "Mehr anzeigen"
  },
  "BUTTON_SELECT": {
    "message": "Ausw\u00e4hlen"
  },
  "BUTTON_SHOW_MORE": {
    "message": "Weitere anzeigen\u2026"
  },
  "BUTTON_TRY": {
    "message": "Hilfe"
  },
  "BUTTON_UDC_SCROLL": {
    "message": "Scrollen"
  },
  "CONTACTS_CONSENT_BODY": {
    "message": "Damit Google Assistant verstehen kann, wen du anrufen oder wem du eine SMS senden m\u00f6chtest, ben\u00f6tigt er die Berechtigung zum Versenden deiner Kontakte an Google, wenn du mit ihm sprichst."
  },
  "CONTACTS_CONSENT_BODY_V02": {
    "message": "Damit Google Assistant verstehen kann, wen du anrufen oder wem du eine SMS senden m\u00f6chtest, ben\u00f6tigt er die Berechtigung, deine Kontakte vor\u00fcbergehend bei Google zu speichern."
  },
  "CONTACTS_CONSENT_TITLE": {
    "message": "Erlaube Google Assistant, auf deine Kontakte zuzugreifen"
  },
  "CONTACTS_CONSENT_TITLE_FOR_REACCEPT": {
    "message": "M\u00f6chtest du Google Assistant erlauben, auf deine Kontakte zuzugreifen, und so dein Nutzererlebnis verbessern?"
  },
  "CONVERSATION_STARTER_CALL": {
    "message": "Einen Anruf machen"
  },
  "CONVERSATION_STARTER_FIND_RESTAURANTS": {
    "message": "Suche Restaurants in meiner N\u00e4he"
  },
  "CONVERSATION_STARTER_JOKE": {
    "message": "Erz\u00e4hl mir einen Witz"
  },
  "CONVERSATION_STARTER_MESSAGE": {
    "message": "Sende eine Nachricht"
  },
  "CONVERSATION_STARTER_OPEN_APP": {
    "message": "\u00d6ffne die Kamera"
  },
  "CONVERSATION_STARTER_PLAY_SONGS": {
    "message": "Spiel Bollywood-Lieder"
  },
  "CONVERSATION_STARTER_YOUTUBE": {
    "message": "\u00d6ffne YouTube"
  },
  "ENDPOINT_TYPE_HOME": {
    "message": "Privat"
  },
  "ENDPOINT_TYPE_MAIN": {
    "message": "Hauptnummer"
  },
  "ENDPOINT_TYPE_MOBILE": {
    "message": "Mobil"
  },
  "ENDPOINT_TYPE_OTHER": {
    "message": "Sonstige"
  },
  "ENDPOINT_TYPE_WORK": {
    "message": "Gesch\u00e4ftlich"
  },
  "EXPLORE_FAILURE_ERROR": {
    "message": "Ein Fehler ist aufgetreten. Bitte versuch es noch einmal."
  },
  "FAIL_UPDATE_BLUETOOTH": {
    "message": "Fehler beim Aktualisieren von Bluetooth. Bitte schalte es unter \"Einstellungen\" manuell ein."
  },
  "FAIL_UPDATE_FLASHLIGHT": {
    "message": "Fehler beim Aktualisieren der Taschenlampe. Bitte schalte sie manuell ein."
  },
  "FAIL_UPDATE_GEOLOCATION": {
    "message": "Fehler beim Aktualisieren der Standortbestimmung. Bitte schalte sie unter \"Einstellungen\" manuell ein."
  },
  "FETCHING_ACCOUNT_STATUS": {
    "message": "Anmeldung wird \u00fcberpr\u00fcft\u2026"
  },
  "INITIAL_PROMPT_MIC": {
    "message": "Zum Sprechen auf $MICROPHONE$ dr\u00fccken",
    "placeholders": {
      "MICROPHONE": {
        "content": "$1"
      }
    }
  },
  "LISTENING": {
    "message": "Jetzt sprechen\u2026"
  },
  "LOCATION_CONSENT_BODY": {
    "message": "Damit lokale Ergebnisse wie etwa Restaurants in deiner Gegend angezeigt werden k\u00f6nnen, ben\u00f6tigt Google Assistant die Berechtigung zum Versenden deines Standorts an Google, wenn du mit ihm sprichst."
  },
  "LOCATION_CONSENT_TITLE": {
    "message": "Erlaube Google Assistant, auf deinen Standort zuzugreifen"
  },
  "LOCATION_CONSENT_TITLE_FOR_REACCEPT": {
    "message": "M\u00f6chtest du Google Assistant Zugriff auf deinen Standort gew\u00e4hren, damit dir st\u00e4rker personalisierte Inhalte angezeigt werden?"
  },
  "MY_ACCOUNT": {
    "message": "Mein Konto"
  },
  "MY_ACCOUNT_BODY": {
    "message": "\"Mein Konto\" wird derzeit auf diesem Ger\u00e4t nicht unterst\u00fctzt. Wenn du deine Kontoinformationen ansehen oder aktualisieren m\u00f6chtest, ruf https://myaccount.google.com/ von einem kompatiblen Ger\u00e4t auf."
  },
  "MY_ACCOUNT_TITLE": {
    "message": "Mein Konto"
  },
  "NETWORK_ERROR": {
    "message": "Verbindung zum Internet nicht m\u00f6glich. Bitte \u00fcberpr\u00fcfe deine Verbindung und versuch es noch einmal."
  },
  "OPEN_APP_SUCCESS": {
    "message": "App wird ge\u00f6ffnet."
  },
  "PLAYER_TITLE_NEWS": {
    "message": "NACHRICHTEN"
  },
  "PLAYER_TITLE_PLACEHOLDER": {
    "message": "Media Player"
  },
  "PUNT_FEATURE_NOT_SUPPORTED": {
    "message": "Tut mir leid, auf diesem Ger\u00e4t funktioniert das nicht. Bitte frag jemand anderen."
  },
  "SERVER_ERROR": {
    "message": "Wir haben ein paar technische Probleme. Bitte versuch es in ein paar Minuten noch mal."
  },
  "SETTINGS_LANGUAGE_TITLE": {
    "message": "In welcher Sprache m\u00f6chtest du am liebsten sprechen?"
  },
  "SETTINGS_OPTION_CHANGE_CONTACTS_PERMISSION": {
    "message": "Berechtigung f\u00fcr den Zugriff auf Kontakte"
  },
  "SETTINGS_OPTION_CHANGE_LANGUAGE": {
    "message": "Sprache \u00e4ndern"
  },
  "SETTINGS_OPTION_CHANGE_LOCATION_PERMISSION": {
    "message": "Standortberechtigung"
  },
  "SETTINGS_OPTION_CLEAR_DATA": {
    "message": "Nutzerdaten l\u00f6schen"
  },
  "SETTINGS_OPTION_PRIVACY_POLICY": {
    "message": "Datenschutzerkl\u00e4rung"
  },
  "SETTINGS_OPTION_TERMS_OF_SERVICE": {
    "message": "Nutzungsbedingungen"
  },
  "SETTINGS_PROMPT": {
    "message": "F\u00fcr Einstellungen $KEY$ dr\u00fccken",
    "placeholders": {
      "KEY": {
        "content": "$1"
      }
    }
  },
  "SETTINGS_TITLE": {
    "message": "Einstellungen"
  },
  "SETTINGS_VERSION": {
    "message": "Version:"
  },
  "SIGNIN": {
    "message": "Anmelden"
  },
  "SIGNOUT": {
    "message": "Abmelden"
  },
  "SNACKBAR_BLUETOOTH_DISABLED": {
    "message": "Bluetooth deaktiviert."
  },
  "SNACKBAR_BLUETOOTH_ENABLED": {
    "message": "Bluetooth aktiviert."
  },
  "SNACKBAR_HISTORY_CLEARED": {
    "message": "Der Verlauf wurde erfolgreich gel\u00f6scht."
  },
  "SNACKBAR_LANGUAGE_PREFERENCE_SAVED": {
    "message": "Spracheinstellung gespeichert."
  },
  "SNACKBAR_NOINPUT_HELP": {
    "message": "Das habe ich nicht verstanden. Bitte sag es noch mal."
  },
  "SNACKBAR_PERMISSION_SAVED": {
    "message": "Berechtigung gespeichert."
  },
  "SUGGESTIONS_PROMPT_MIC": {
    "message": "Dr\u00fcck $MICROPHONE$ und sag dabei...",
    "placeholders": {
      "MICROPHONE": {
        "content": "$1"
      }
    }
  },
  "SUGGESTION_ANSWER": {
    "message": "\"Wie ist das Wetter?\""
  },
  "SUGGESTION_BLUETOOTH": {
    "message": "\"Schalt Bluetooth ein\""
  },
  "SUGGESTION_CALL": {
    "message": "\"Ruf Sophia an\""
  },
  "SUGGESTION_CALL_EN_IN": {
    "message": "\"Ruf Anjali an\""
  },
  "SUGGESTION_PICTURES": {
    "message": "\"Zeig mir Bilder von Beyonc\u00e9\""
  },
  "SUGGESTION_PICTURES_EN_IN": {
    "message": "\"Zeig mir Bilder von Shah Rukh Khan\""
  },
  "SUGGESTION_SMS": {
    "message": "\"SMS an Jens senden\""
  },
  "SUGGESTION_SMS_EN_IN": {
    "message": "\"Sende eine SMS an Akshay\""
  },
  "SUGGESTION_YOUTUBE": {
    "message": "\"Spiel Lady Gaga auf YouTube\""
  },
  "SUGGESTION_YOUTUBE_EN_IN": {
    "message": "\"Spiel Kala Chashma auf YouTube\""
  },
  "TERMS_AND_CONDITIONS_BODY_PRIVACY": {
    "message": "Dr\u00fcck 2, um die Datenschutzrichtlinie zu lesen:"
  },
  "TERMS_AND_CONDITIONS_BODY_TERMS": {
    "message": "Dr\u00fccke 1, um die Nutzungsbedingungen zu lesen:"
  },
  "TERMS_AND_CONDITIONS_TITLE": {
    "message": "Bitte lies die Nutzungsbedingungen und Datenschutzrichtlinien von Google"
  },
  "UDC_SETTINGS_LEARN_MORE_PROMPT": {
    "message": "$INDEX$ dr\u00fccken, um mehr zu erfahren",
    "placeholders": {
      "INDEX": {
        "content": "$1"
      }
    }
  },
  "UNKNOWN_CONNECTION_ERROR": {
    "message": "Es gibt technische Probleme."
  },
  "VERSION_EXPIRED_ERROR": {
    "message": "Diese App ist veraltet. Bitte wende dich wegen der Aktualisierung auf die aktuelle Version an deinen Anbieter."
  }
};
