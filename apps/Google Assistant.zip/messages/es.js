opa.Messages['es'] = {
  "ACTION_TEXT_RESPONSE_NO_CONTACTS": {
    "message": "No se ha encontrado ning\u00fan contacto."
  },
  "ACTION_TEXT_RESPONSE_OK": {
    "message": "Aceptar"
  },
  "ACTION_VOCAL_RESPONSE_NO_CONTACTS": {
    "message": "No se ha encontrado ning\u00fan contacto."
  },
  "ACTION_VOCAL_RESPONSE_OK": {
    "message": "Aceptar"
  },
  "ACTION_VOCAL_RESPONSE_SENDING_MESSAGE": {
    "message": "Enviando mensaje."
  },
  "ACTION_VOCAL_RESPONSE_SMS_TIMEOUT": {
    "message": "Se est\u00e1 tardando m\u00e1s de lo habitual en enviar tu mensaje. Int\u00e9ntalo de nuevo en unos minutos."
  },
  "APP_NOT_FOUND_ERROR": {
    "message": "No he encontrado esa aplicaci\u00f3n."
  },
  "BUTTON_ACCEPT": {
    "message": "Aceptar"
  },
  "BUTTON_AGREE": {
    "message": "Aceptar"
  },
  "BUTTON_ALLOW": {
    "message": "Permitir"
  },
  "BUTTON_BACK": {
    "message": "Atr\u00e1s"
  },
  "BUTTON_CANCEL": {
    "message": "Cancelar"
  },
  "BUTTON_DENY": {
    "message": "No, gracias"
  },
  "BUTTON_EXIT": {
    "message": "Salir"
  },
  "BUTTON_EXPLORE": {
    "message": "Explorar"
  },
  "BUTTON_GOOGLE_DOT_COM": {
    "message": "Google.com"
  },
  "BUTTON_HOME": {
    "message": "P\u00e1gina principal"
  },
  "BUTTON_NEXT": {
    "message": "Siguiente"
  },
  "BUTTON_OK": {
    "message": "Aceptar"
  },
  "BUTTON_OPEN": {
    "message": "Abrir"
  },
  "BUTTON_REFRESH": {
    "message": "Actualizar"
  },
  "BUTTON_SEARCH": {
    "message": "Buscar"
  },
  "BUTTON_SEARCH_ON_GOOGLE": {
    "message": "Buscar en Google"
  },
  "BUTTON_SEE_MORE": {
    "message": "Ver m\u00e1s"
  },
  "BUTTON_SELECT": {
    "message": "Seleccionar"
  },
  "BUTTON_SHOW_MORE": {
    "message": "Mostrar m\u00e1s..."
  },
  "BUTTON_TRY": {
    "message": "Ayuda"
  },
  "BUTTON_UDC_SCROLL": {
    "message": "Desplazar"
  },
  "CONTACTS_CONSENT_BODY": {
    "message": "Para entender a qui\u00e9n quieres llamar o enviar un mensaje, el Asistente necesita permiso para enviar tus contactos a Google siempre que hables con \u00e9l."
  },
  "CONTACTS_CONSENT_BODY_V02": {
    "message": "Para entender a qui\u00e9n quieres llamar o enviar un mensaje, el Asistente necesita permiso para almacenar tus contactos en Google de forma temporal."
  },
  "CONTACTS_CONSENT_TITLE": {
    "message": "Permite que el Asistente de Google acceda a tus contactos"
  },
  "CONTACTS_CONSENT_TITLE_FOR_REACCEPT": {
    "message": "Para disfrutar de una experiencia a\u00fan mejor, \u00bfdar\u00edas permiso al Asistente de Google para acceder a tus contactos?"
  },
  "CONVERSATION_STARTER_CALL": {
    "message": "Llamar por tel\u00e9fono"
  },
  "CONVERSATION_STARTER_FIND_RESTAURANTS": {
    "message": "Busca restaurantes cercanos"
  },
  "CONVERSATION_STARTER_JOKE": {
    "message": "Cu\u00e9ntame un chiste"
  },
  "CONVERSATION_STARTER_MESSAGE": {
    "message": "Env\u00eda un mensaje"
  },
  "CONVERSATION_STARTER_OPEN_APP": {
    "message": "Abre la c\u00e1mara"
  },
  "CONVERSATION_STARTER_PLAY_SONGS": {
    "message": "Pon canciones de Bollywood"
  },
  "CONVERSATION_STARTER_YOUTUBE": {
    "message": "Abre YouTube"
  },
  "ENDPOINT_TYPE_HOME": {
    "message": "casa"
  },
  "ENDPOINT_TYPE_MAIN": {
    "message": "principal"
  },
  "ENDPOINT_TYPE_MOBILE": {
    "message": "m\u00f3vil"
  },
  "ENDPOINT_TYPE_OTHER": {
    "message": "otro"
  },
  "ENDPOINT_TYPE_WORK": {
    "message": "trabajo"
  },
  "EXPLORE_FAILURE_ERROR": {
    "message": "Se ha producido un error. Int\u00e9ntalo de nuevo."
  },
  "FAIL_UPDATE_BLUETOOTH": {
    "message": "No se ha podido actualizar el Bluetooth. Act\u00edvalo manualmente en Ajustes."
  },
  "FAIL_UPDATE_FLASHLIGHT": {
    "message": "No se ha podido actualizar la linterna. Debes activarla manualmente."
  },
  "FAIL_UPDATE_GEOLOCATION": {
    "message": "No se puede actualizar la geolocalizaci\u00f3n. Act\u00edvala manualmente en Ajustes."
  },
  "FETCHING_ACCOUNT_STATUS": {
    "message": "Se est\u00e1 comprobando el inicio de sesi\u00f3n\u2026"
  },
  "INITIAL_PROMPT_MIC": {
    "message": "Pulsa $MICROPHONE$ para hablar",
    "placeholders": {
      "MICROPHONE": {
        "content": "$1"
      }
    }
  },
  "LISTENING": {
    "message": "Escuchando\u2026"
  },
  "LOCATION_CONSENT_BODY": {
    "message": "Para obtener resultados locales, como los restaurantes de la zona, el Asistente necesita permiso para enviar tu ubicaci\u00f3n a Google siempre que hables con \u00e9l."
  },
  "LOCATION_CONSENT_TITLE": {
    "message": "Permite que el Asistente de Google acceda a tu ubicaci\u00f3n"
  },
  "LOCATION_CONSENT_TITLE_FOR_REACCEPT": {
    "message": "Para disfrutar de una experiencia m\u00e1s personalizada, \u00bfpermitir\u00edas que el Asistente de Google pueda acceder a tu ubicaci\u00f3n?"
  },
  "MY_ACCOUNT": {
    "message": "Mi Cuenta"
  },
  "MY_ACCOUNT_BODY": {
    "message": "En estos momentos, la p\u00e1gina Mi Cuenta no es compatible con este dispositivo. Para poder ver o modificar la informaci\u00f3n de tu cuenta, visita https://myaccount.google.com/ desde un dispositivo compatible."
  },
  "MY_ACCOUNT_TITLE": {
    "message": "Mi Cuenta"
  },
  "NETWORK_ERROR": {
    "message": "No se puede conectar a Internet. Comprueba que tengas conexi\u00f3n y vuelve a intentarlo."
  },
  "OPEN_APP_SUCCESS": {
    "message": "Abriendo aplicaci\u00f3n."
  },
  "PLAYER_TITLE_NEWS": {
    "message": "NOTICIAS"
  },
  "PLAYER_TITLE_PLACEHOLDER": {
    "message": "Media Player"
  },
  "PUNT_FEATURE_NOT_SUPPORTED": {
    "message": "Lo siento, no puedo hacer eso en este dispositivo. Prueba con otra acci\u00f3n."
  },
  "SERVER_ERROR": {
    "message": "Estamos teniendo problemas t\u00e9cnicos. Vuelve a intentarlo dentro de un par de minutos."
  },
  "SETTINGS_LANGUAGE_TITLE": {
    "message": "\u00bfEn qu\u00e9 idioma prefieres hablar?"
  },
  "SETTINGS_OPTION_CHANGE_CONTACTS_PERMISSION": {
    "message": "Permiso para usar contactos"
  },
  "SETTINGS_OPTION_CHANGE_LANGUAGE": {
    "message": "Cambiar idioma"
  },
  "SETTINGS_OPTION_CHANGE_LOCATION_PERMISSION": {
    "message": "Permiso de ubicaci\u00f3n"
  },
  "SETTINGS_OPTION_CLEAR_DATA": {
    "message": "Borrar datos de usuario"
  },
  "SETTINGS_OPTION_PRIVACY_POLICY": {
    "message": "Pol\u00edtica de privacidad"
  },
  "SETTINGS_OPTION_TERMS_OF_SERVICE": {
    "message": "Condiciones de servicio"
  },
  "SETTINGS_PROMPT": {
    "message": "Pulsa $KEY$ para ir a Ajustes",
    "placeholders": {
      "KEY": {
        "content": "$1"
      }
    }
  },
  "SETTINGS_TITLE": {
    "message": "Ajustes"
  },
  "SETTINGS_VERSION": {
    "message": "Versi\u00f3n:"
  },
  "SIGNIN": {
    "message": "Iniciar sesi\u00f3n"
  },
  "SIGNOUT": {
    "message": "Cerrar sesi\u00f3n"
  },
  "SNACKBAR_BLUETOOTH_DISABLED": {
    "message": "Bluetooth inhabilitado."
  },
  "SNACKBAR_BLUETOOTH_ENABLED": {
    "message": "Bluetooth habilitado."
  },
  "SNACKBAR_HISTORY_CLEARED": {
    "message": "Has borrado tu historial correctamente."
  },
  "SNACKBAR_LANGUAGE_PREFERENCE_SAVED": {
    "message": "Se ha guardado la preferencia de idioma."
  },
  "SNACKBAR_NOINPUT_HELP": {
    "message": "No lo he entendido. \u00bfPuedes repetirlo?"
  },
  "SNACKBAR_PERMISSION_SAVED": {
    "message": "Se ha guardado el permiso."
  },
  "SUGGESTIONS_PROMPT_MIC": {
    "message": "Pulsa $MICROPHONE$ y di\u2026",
    "placeholders": {
      "MICROPHONE": {
        "content": "$1"
      }
    }
  },
  "SUGGESTION_ANSWER": {
    "message": "\"\u00bfQu\u00e9 tiempo hace?\""
  },
  "SUGGESTION_BLUETOOTH": {
    "message": "\"Activa el Bluetooth\""
  },
  "SUGGESTION_CALL": {
    "message": "\"Llama a M\u00f3nica\""
  },
  "SUGGESTION_CALL_EN_IN": {
    "message": "\"Llama a Irene\""
  },
  "SUGGESTION_PICTURES": {
    "message": "\"Mu\u00e9strame fotos de Beyonc\u00e9\""
  },
  "SUGGESTION_PICTURES_EN_IN": {
    "message": "\"Mu\u00e9strame im\u00e1genes de Alfredo Landa\""
  },
  "SUGGESTION_SMS": {
    "message": "\"Env\u00eda un mensaje a Juan\""
  },
  "SUGGESTION_SMS_EN_IN": {
    "message": "\"Env\u00eda un mensaje a Lola\""
  },
  "SUGGESTION_YOUTUBE": {
    "message": "\"Pon Lady Gaga en YouTube\""
  },
  "SUGGESTION_YOUTUBE_EN_IN": {
    "message": "\"Pon Despacito en YouTube\""
  },
  "TERMS_AND_CONDITIONS_BODY_PRIVACY": {
    "message": "Pulsa 2 para leer la pol\u00edtica de privacidad:"
  },
  "TERMS_AND_CONDITIONS_BODY_TERMS": {
    "message": "Pulsa 1 para leer las condiciones de servicio:"
  },
  "TERMS_AND_CONDITIONS_TITLE": {
    "message": "Lee la pol\u00edtica de privacidad y las condiciones de servicio de Google"
  },
  "UDC_SETTINGS_LEARN_MORE_PROMPT": {
    "message": "Pulsa $INDEX$ para obtener m\u00e1s informaci\u00f3n",
    "placeholders": {
      "INDEX": {
        "content": "$1"
      }
    }
  },
  "UNKNOWN_CONNECTION_ERROR": {
    "message": "Estamos teniendo problemas t\u00e9cnicos."
  },
  "VERSION_EXPIRED_ERROR": {
    "message": "La aplicaci\u00f3n no est\u00e1 actualizada. Ponte en contacto con el proveedor para actualizarla a la \u00faltima versi\u00f3n."
  }
};
