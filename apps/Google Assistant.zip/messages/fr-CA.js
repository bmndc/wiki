opa.Messages['fr-CA'] = {
  "ACTION_TEXT_RESPONSE_NO_CONTACTS": {
    "message": "Aucun contact trouv\u00e9."
  },
  "ACTION_TEXT_RESPONSE_OK": {
    "message": "OK"
  },
  "ACTION_VOCAL_RESPONSE_NO_CONTACTS": {
    "message": "Aucun contact trouv\u00e9."
  },
  "ACTION_VOCAL_RESPONSE_OK": {
    "message": "OK"
  },
  "ACTION_VOCAL_RESPONSE_SENDING_MESSAGE": {
    "message": "Envoi du message en cours."
  },
  "ACTION_VOCAL_RESPONSE_SMS_TIMEOUT": {
    "message": "L'envoi de votre message prend plus de temps que d'habitude. R\u00e9essayez dans quelques minutes."
  },
  "APP_NOT_FOUND_ERROR": {
    "message": "Cette application est introuvable."
  },
  "BUTTON_ACCEPT": {
    "message": "Accepter"
  },
  "BUTTON_AGREE": {
    "message": "Accepter"
  },
  "BUTTON_ALLOW": {
    "message": "Autoriser"
  },
  "BUTTON_BACK": {
    "message": "Pr\u00e9c\u00e9dent"
  },
  "BUTTON_CANCEL": {
    "message": "Annuler"
  },
  "BUTTON_DENY": {
    "message": "Non merci"
  },
  "BUTTON_EXIT": {
    "message": "Quitter"
  },
  "BUTTON_EXPLORE": {
    "message": "Explorer"
  },
  "BUTTON_GOOGLE_DOT_COM": {
    "message": "Google.ca"
  },
  "BUTTON_HOME": {
    "message": "Accueil"
  },
  "BUTTON_NEXT": {
    "message": "Suivant"
  },
  "BUTTON_OK": {
    "message": "OK"
  },
  "BUTTON_OPEN": {
    "message": "Ouvrir"
  },
  "BUTTON_REFRESH": {
    "message": "Actualiser"
  },
  "BUTTON_SEARCH": {
    "message": "Rechercher"
  },
  "BUTTON_SEARCH_ON_GOOGLE": {
    "message": "Rechercher sur Google"
  },
  "BUTTON_SEE_MORE": {
    "message": "Voir plus"
  },
  "BUTTON_SELECT": {
    "message": "S\u00e9lectionner"
  },
  "BUTTON_SHOW_MORE": {
    "message": "Plus\u2026"
  },
  "BUTTON_TRY": {
    "message": "Aide"
  },
  "BUTTON_UDC_SCROLL": {
    "message": "Faire d\u00e9filer"
  },
  "CONTACTS_CONSENT_BODY": {
    "message": "Afin de comprendre \u00e0 qui vous souhaitez t\u00e9l\u00e9phoner ou envoyer un message texte, l'Assistant Google n\u00e9cessite une autorisation pour envoyer vos contacts \u00e0 Google chaque fois que vous lui parlez."
  },
  "CONTACTS_CONSENT_BODY_V02": {
    "message": "Afin de comprendre \u00e0 qui vous souhaitez t\u00e9l\u00e9phoner ou envoyer un message texte, l'Assistant Google n\u00e9cessite une autorisation pour temporairement stocker vos contacts par l'entremise de Google."
  },
  "CONTACTS_CONSENT_TITLE": {
    "message": "Autoriser l'Assistant Google \u00e0 acc\u00e9der \u00e0 vos contacts"
  },
  "CONTACTS_CONSENT_TITLE_FOR_REACCEPT": {
    "message": "Afin de profiter d'une exp\u00e9rience plus personnalis\u00e9e, acceptez-vous d'autoriser l'Assistant Google \u00e0 acc\u00e9der \u00e0 vos contacts?"
  },
  "CONVERSATION_STARTER_CALL": {
    "message": "Passer un appel t\u00e9l\u00e9phonique"
  },
  "CONVERSATION_STARTER_FIND_RESTAURANTS": {
    "message": "Trouve des restaurants \u00e0 proximit\u00e9"
  },
  "CONVERSATION_STARTER_JOKE": {
    "message": "Raconte-moi une blague"
  },
  "CONVERSATION_STARTER_MESSAGE": {
    "message": "Envoie un message"
  },
  "CONVERSATION_STARTER_OPEN_APP": {
    "message": "Ouvre la cam\u00e9ra"
  },
  "CONVERSATION_STARTER_PLAY_SONGS": {
    "message": "Fais jouer des chansons de Bollywood"
  },
  "CONVERSATION_STARTER_YOUTUBE": {
    "message": "Ouvre YouTube"
  },
  "ENDPOINT_TYPE_HOME": {
    "message": "domicile"
  },
  "ENDPOINT_TYPE_MAIN": {
    "message": "principal"
  },
  "ENDPOINT_TYPE_MOBILE": {
    "message": "appareil mobile"
  },
  "ENDPOINT_TYPE_OTHER": {
    "message": "autre"
  },
  "ENDPOINT_TYPE_WORK": {
    "message": "travail"
  },
  "EXPLORE_FAILURE_ERROR": {
    "message": "Une erreur s'est produite. R\u00e9essayez."
  },
  "FAIL_UPDATE_BLUETOOTH": {
    "message": "La mise \u00e0 jour de Bluetooth a \u00e9chou\u00e9; veuillez l'activer manuellement dans les param\u00e8tres."
  },
  "FAIL_UPDATE_FLASHLIGHT": {
    "message": "\u00c9chec de mise \u00e0 jour de la lampe de poche; veuillez l'activer manuellement."
  },
  "FAIL_UPDATE_GEOLOCATION": {
    "message": "La mise \u00e0 jour de la g\u00e9olocalisation a \u00e9chou\u00e9; veuillez l'activer manuellement dans les param\u00e8tres."
  },
  "FETCHING_ACCOUNT_STATUS": {
    "message": "V\u00e9rification de la connexion\u2026"
  },
  "INITIAL_PROMPT_MIC": {
    "message": "Appuyez sur $MICROPHONE$ pour parler",
    "placeholders": {
      "MICROPHONE": {
        "content": "$1"
      }
    }
  },
  "LISTENING": {
    "message": "\u00c9coute en cours\u2026"
  },
  "LOCATION_CONSENT_BODY": {
    "message": "Afin que vous puissiez recevoir des r\u00e9sultats locaux, comme les restaurants de votre r\u00e9gion, l'Assistant Google n\u00e9cessite une autorisation pour envoyer votre position \u00e0 Google chaque fois que vous lui parlez."
  },
  "LOCATION_CONSENT_TITLE": {
    "message": "Autoriser l'Assistant Google \u00e0 acc\u00e9der \u00e0 votre position"
  },
  "LOCATION_CONSENT_TITLE_FOR_REACCEPT": {
    "message": "Afin de profiter d'une exp\u00e9rience plus personnalis\u00e9e, acceptez-vous d'autoriser l'Assistant Google \u00e0 acc\u00e9der \u00e0 votre position?"
  },
  "MY_ACCOUNT": {
    "message": "Mon compte"
  },
  "MY_ACCOUNT_BODY": {
    "message": "Mon compte n'est actuellement pas pris en charge sur cet appareil. Pour consulter ou mettre \u00e0 jour les renseignements de votre compte, acc\u00e9dez \u00e0 la page https://myaccount.google.com/ \u00e0 partir d'un appareil compatible."
  },
  "MY_ACCOUNT_TITLE": {
    "message": "Mon compte"
  },
  "NETWORK_ERROR": {
    "message": "Impossible de se connecter \u00e0 Internet. Veuillez v\u00e9rifier votre connexion et r\u00e9essayer."
  },
  "OPEN_APP_SUCCESS": {
    "message": "Ouverture de l'application en cours."
  },
  "PLAYER_TITLE_NEWS": {
    "message": "ACTUALIT\u00c9S"
  },
  "PLAYER_TITLE_PLACEHOLDER": {
    "message": "Media Player"
  },
  "PUNT_FEATURE_NOT_SUPPORTED": {
    "message": "D\u00e9sol\u00e9e, je ne peux effectuer cette op\u00e9ration sur cet appareil. Essayez de demander autre chose."
  },
  "SERVER_ERROR": {
    "message": "Nous rencontrons des difficult\u00e9s techniques. Veuillez r\u00e9essayer dans quelques minutes."
  },
  "SETTINGS_LANGUAGE_TITLE": {
    "message": "Dans quelle langue pr\u00e9f\u00e9rez-vous parler?"
  },
  "SETTINGS_OPTION_CHANGE_CONTACTS_PERMISSION": {
    "message": "Autorisation des contacts"
  },
  "SETTINGS_OPTION_CHANGE_LANGUAGE": {
    "message": "Changer la langue"
  },
  "SETTINGS_OPTION_CHANGE_LOCATION_PERMISSION": {
    "message": "Autorisation d'acc\u00e9der \u00e0 la position"
  },
  "SETTINGS_OPTION_CLEAR_DATA": {
    "message": "Effacer les donn\u00e9es de l'utilisateur"
  },
  "SETTINGS_OPTION_PRIVACY_POLICY": {
    "message": "Politique de confidentialit\u00e9"
  },
  "SETTINGS_OPTION_TERMS_OF_SERVICE": {
    "message": "Conditions d'utilisation"
  },
  "SETTINGS_PROMPT": {
    "message": "Appuyez sur $KEY$ pour acc\u00e9der aux param\u00e8tres",
    "placeholders": {
      "KEY": {
        "content": "$1"
      }
    }
  },
  "SETTINGS_TITLE": {
    "message": "Param\u00e8tres"
  },
  "SETTINGS_VERSION": {
    "message": "Version\u00a0:"
  },
  "SIGNIN": {
    "message": "Connexion"
  },
  "SIGNOUT": {
    "message": "D\u00e9connexion"
  },
  "SNACKBAR_BLUETOOTH_DISABLED": {
    "message": "Bluetooth d\u00e9sactiv\u00e9."
  },
  "SNACKBAR_BLUETOOTH_ENABLED": {
    "message": "Bluetooth activ\u00e9."
  },
  "SNACKBAR_HISTORY_CLEARED": {
    "message": "Vous avez bien effac\u00e9 votre historique."
  },
  "SNACKBAR_LANGUAGE_PREFERENCE_SAVED": {
    "message": "Pr\u00e9f\u00e9rence de langue enregistr\u00e9e."
  },
  "SNACKBAR_NOINPUT_HELP": {
    "message": "Je n'ai pas compris. Veuillez r\u00e9p\u00e9ter."
  },
  "SNACKBAR_PERMISSION_SAVED": {
    "message": "Autorisation enregistr\u00e9e."
  },
  "SUGGESTIONS_PROMPT_MIC": {
    "message": "Appuyez sur le $MICROPHONE$ et essayez de dire\u2026",
    "placeholders": {
      "MICROPHONE": {
        "content": "$1"
      }
    }
  },
  "SUGGESTION_ANSWER": {
    "message": "\u00ab\u00a0Quel temps fait-il?\u00a0\u00bb"
  },
  "SUGGESTION_BLUETOOTH": {
    "message": "\u00ab\u00a0Active Bluetooth\u00a0\u00bb"
  },
  "SUGGESTION_CALL": {
    "message": "\u00ab\u00a0Appelle Sophie\u00a0\u00bb"
  },
  "SUGGESTION_CALL_EN_IN": {
    "message": "\u00ab\u00a0Appelle Anjali\u00a0\u00bb"
  },
  "SUGGESTION_PICTURES": {
    "message": "\u00ab\u00a0Montre-moi des photos de Beyonc\u00e9\u00a0\u00bb"
  },
  "SUGGESTION_PICTURES_EN_IN": {
    "message": "\u00ab\u00a0Montre-moi des photos de Shah Rukh Khan\u00a0\u00bb"
  },
  "SUGGESTION_SMS": {
    "message": "\u00ab\u00a0Envoie un message \u00e0 Jean\u00a0\u00bb"
  },
  "SUGGESTION_SMS_EN_IN": {
    "message": "\u00ab\u00a0Envoie un message \u00e0 Akshay\u00a0\u00bb"
  },
  "SUGGESTION_YOUTUBE": {
    "message": "\u00ab\u00a0Fais jouer Lady Gaga sur YouTube\u00a0\u00bb"
  },
  "SUGGESTION_YOUTUBE_EN_IN": {
    "message": "\u00ab\u00a0Fais jouer Kala Chashma sur YouTube\u00a0\u00bb"
  },
  "TERMS_AND_CONDITIONS_BODY_PRIVACY": {
    "message": "Appuyez sur la touche\u00a02 de votre clavier pour lire la politique de confidentialit\u00e9\u00a0:"
  },
  "TERMS_AND_CONDITIONS_BODY_TERMS": {
    "message": "Appuyez sur la touche\u00a01 de votre clavier pour lire les conditions d'utilisation\u00a0:"
  },
  "TERMS_AND_CONDITIONS_TITLE": {
    "message": "Veuillez lire les Conditions d'utilisation et la politique de confidentialit\u00e9 de Google"
  },
  "UDC_SETTINGS_LEARN_MORE_PROMPT": {
    "message": "Appuyez sur $INDEX$ pour en savoir plus",
    "placeholders": {
      "INDEX": {
        "content": "$1"
      }
    }
  },
  "UNKNOWN_CONNECTION_ERROR": {
    "message": "Nous rencontrons des difficult\u00e9s techniques."
  },
  "VERSION_EXPIRED_ERROR": {
    "message": "L'application est obsol\u00e8te. Veuillez communiquer avec votre fournisseur pour installer la derni\u00e8re version."
  }
};
