opa.Messages['es-MX'] = {
  "ACTION_TEXT_RESPONSE_NO_CONTACTS": {
    "message": "No se encontraron contactos."
  },
  "ACTION_TEXT_RESPONSE_OK": {
    "message": "Aceptar"
  },
  "ACTION_VOCAL_RESPONSE_NO_CONTACTS": {
    "message": "No se encontraron contactos."
  },
  "ACTION_VOCAL_RESPONSE_OK": {
    "message": "Aceptar"
  },
  "ACTION_VOCAL_RESPONSE_SENDING_MESSAGE": {
    "message": "Enviando mensaje"
  },
  "ACTION_VOCAL_RESPONSE_SMS_TIMEOUT": {
    "message": "El env\u00edo del mensaje est\u00e1 tardando m\u00e1s de lo normal. Vuelve a intentarlo en unos minutos."
  },
  "APP_NOT_FOUND_ERROR": {
    "message": "No encontr\u00e9 esa app."
  },
  "BUTTON_ACCEPT": {
    "message": "Aceptar"
  },
  "BUTTON_AGREE": {
    "message": "Aceptar"
  },
  "BUTTON_ALLOW": {
    "message": "Permitir"
  },
  "BUTTON_BACK": {
    "message": "Atr\u00e1s"
  },
  "BUTTON_CANCEL": {
    "message": "Cancelar"
  },
  "BUTTON_DENY": {
    "message": "No, gracias"
  },
  "BUTTON_EXIT": {
    "message": "Salir"
  },
  "BUTTON_EXPLORE": {
    "message": "Explorar"
  },
  "BUTTON_GOOGLE_DOT_COM": {
    "message": "Google.com"
  },
  "BUTTON_HOME": {
    "message": "Inicio"
  },
  "BUTTON_NEXT": {
    "message": "Siguiente"
  },
  "BUTTON_OK": {
    "message": "Aceptar"
  },
  "BUTTON_OPEN": {
    "message": "Abrir"
  },
  "BUTTON_REFRESH": {
    "message": "Actualizar"
  },
  "BUTTON_SEARCH": {
    "message": "Buscar"
  },
  "BUTTON_SEARCH_ON_GOOGLE": {
    "message": "Buscar en Google"
  },
  "BUTTON_SEE_MORE": {
    "message": "Ver m\u00e1s"
  },
  "BUTTON_SELECT": {
    "message": "Seleccionar"
  },
  "BUTTON_SHOW_MORE": {
    "message": "Mostrar m\u00e1s\u2026"
  },
  "BUTTON_TRY": {
    "message": "Ayuda"
  },
  "BUTTON_UDC_SCROLL": {
    "message": "Desplazar"
  },
  "CONTACTS_CONSENT_BODY": {
    "message": "Para entender a qui\u00e9n quieres llamar o enviar un mensaje, el Asistente necesita permiso para enviar tus contactos a Google siempre que hables con \u00e9l."
  },
  "CONTACTS_CONSENT_BODY_V02": {
    "message": "Para entender a qui\u00e9n quieres llamar o enviarle un mensaje, el Asistente necesita permiso para almacenar temporalmente tus contactos con Google."
  },
  "CONTACTS_CONSENT_TITLE": {
    "message": "Permite que el Asistente\u00a0de\u00a0Google acceda a tus contactos"
  },
  "CONTACTS_CONSENT_TITLE_FOR_REACCEPT": {
    "message": "Para disfrutar de una experiencia a\u00fan mejor, \u00bfpodr\u00edas permitir que el Asistente\u00a0de\u00a0Google acceda a tus contactos?"
  },
  "CONVERSATION_STARTER_CALL": {
    "message": "Haz una llamada telef\u00f3nica"
  },
  "CONVERSATION_STARTER_FIND_RESTAURANTS": {
    "message": "Encuentra restaurantes cercanos"
  },
  "CONVERSATION_STARTER_JOKE": {
    "message": "Cu\u00e9ntame un chiste"
  },
  "CONVERSATION_STARTER_MESSAGE": {
    "message": "Env\u00eda un mensaje"
  },
  "CONVERSATION_STARTER_OPEN_APP": {
    "message": "Abre la c\u00e1mara"
  },
  "CONVERSATION_STARTER_PLAY_SONGS": {
    "message": "Reproduce canciones de Bollywood"
  },
  "CONVERSATION_STARTER_YOUTUBE": {
    "message": "Abre YouTube"
  },
  "ENDPOINT_TYPE_HOME": {
    "message": "casa"
  },
  "ENDPOINT_TYPE_MAIN": {
    "message": "principal"
  },
  "ENDPOINT_TYPE_MOBILE": {
    "message": "dispositivo m\u00f3vil"
  },
  "ENDPOINT_TYPE_OTHER": {
    "message": "otro"
  },
  "ENDPOINT_TYPE_WORK": {
    "message": "trabajo"
  },
  "EXPLORE_FAILURE_ERROR": {
    "message": "Se produjo un error. Vuelve a intentarlo."
  },
  "FAIL_UPDATE_BLUETOOTH": {
    "message": "No se pudo actualizar el Bluetooth. Act\u00edvalo manualmente en Configuraci\u00f3n."
  },
  "FAIL_UPDATE_FLASHLIGHT": {
    "message": "No se pudo actualizar la linterna. Enci\u00e9ndela manualmente."
  },
  "FAIL_UPDATE_GEOLOCATION": {
    "message": "No se pudo actualizar la ubicaci\u00f3n geogr\u00e1fica. Act\u00edvala manualmente en Configuraci\u00f3n."
  },
  "FETCHING_ACCOUNT_STATUS": {
    "message": "Verificando cuenta para el acceso\u2026"
  },
  "INITIAL_PROMPT_MIC": {
    "message": "Presiona $MICROPHONE$ para hablar",
    "placeholders": {
      "MICROPHONE": {
        "content": "$1"
      }
    }
  },
  "LISTENING": {
    "message": "Escuchando\u2026"
  },
  "LOCATION_CONSENT_BODY": {
    "message": "Para obtener resultados locales, como restaurantes de la zona, el Asistente necesita permiso para enviar tu ubicaci\u00f3n a Google siempre que hables con \u00e9l."
  },
  "LOCATION_CONSENT_TITLE": {
    "message": "Permite que el Asistente\u00a0de\u00a0Google acceda a tu ubicaci\u00f3n"
  },
  "LOCATION_CONSENT_TITLE_FOR_REACCEPT": {
    "message": "Para disfrutar de una experiencia m\u00e1s personalizada, \u00bfpodr\u00edas permitir que el Asistente\u00a0de\u00a0Google acceda a tu ubicaci\u00f3n?"
  },
  "MY_ACCOUNT": {
    "message": "Mi cuenta"
  },
  "MY_ACCOUNT_BODY": {
    "message": "Por el momento, la p\u00e1gina \"Mi cuenta\" no es compatible con este dispositivo. Para ver o modificar la informaci\u00f3n de tu cuenta, visita https://myaccount.google.com/ en un dispositivo compatible."
  },
  "MY_ACCOUNT_TITLE": {
    "message": "Mi cuenta"
  },
  "NETWORK_ERROR": {
    "message": "No se puede conectar a Internet. Revisa tu conexi\u00f3n y vuelve a intentarlo."
  },
  "OPEN_APP_SUCCESS": {
    "message": "Abriendo app\u2026"
  },
  "PLAYER_TITLE_NEWS": {
    "message": "NOTICIAS"
  },
  "PLAYER_TITLE_PLACEHOLDER": {
    "message": "Media Player"
  },
  "PUNT_FEATURE_NOT_SUPPORTED": {
    "message": "Lo siento, pero no puedo hacer eso en este dispositivo. Prueba con otra acci\u00f3n."
  },
  "SERVER_ERROR": {
    "message": "Estamos teniendo problemas t\u00e9cnicos. Vuelve a intentarlo en algunos minutos."
  },
  "SETTINGS_LANGUAGE_TITLE": {
    "message": "\u00bfEn qu\u00e9 idioma prefieres hablar?"
  },
  "SETTINGS_OPTION_CHANGE_CONTACTS_PERMISSION": {
    "message": "Permiso de contactos"
  },
  "SETTINGS_OPTION_CHANGE_LANGUAGE": {
    "message": "Cambiar idioma"
  },
  "SETTINGS_OPTION_CHANGE_LOCATION_PERMISSION": {
    "message": "Permiso de ubicaci\u00f3n"
  },
  "SETTINGS_OPTION_CLEAR_DATA": {
    "message": "Borrar datos del usuario"
  },
  "SETTINGS_OPTION_PRIVACY_POLICY": {
    "message": "Pol\u00edtica de Privacidad"
  },
  "SETTINGS_OPTION_TERMS_OF_SERVICE": {
    "message": "Condiciones del servicio"
  },
  "SETTINGS_PROMPT": {
    "message": "Presiona $KEY$ para acceder a la Configuraci\u00f3n",
    "placeholders": {
      "KEY": {
        "content": "$1"
      }
    }
  },
  "SETTINGS_TITLE": {
    "message": "Configuraci\u00f3n"
  },
  "SETTINGS_VERSION": {
    "message": "Versi\u00f3n:"
  },
  "SIGNIN": {
    "message": "Acceder"
  },
  "SIGNOUT": {
    "message": "Salir"
  },
  "SNACKBAR_BLUETOOTH_DISABLED": {
    "message": "Bluetooth inhabilitado"
  },
  "SNACKBAR_BLUETOOTH_ENABLED": {
    "message": "Bluetooth habilitado"
  },
  "SNACKBAR_HISTORY_CLEARED": {
    "message": "Borraste el historial correctamente."
  },
  "SNACKBAR_LANGUAGE_PREFERENCE_SAVED": {
    "message": "Se guardaron las preferencias de idioma."
  },
  "SNACKBAR_NOINPUT_HELP": {
    "message": "No entend\u00ed. Vuelve a intentarlo."
  },
  "SNACKBAR_PERMISSION_SAVED": {
    "message": "Se guard\u00f3 el permiso."
  },
  "SUGGESTIONS_PROMPT_MIC": {
    "message": "Presiona $MICROPHONE$ y di\u2026",
    "placeholders": {
      "MICROPHONE": {
        "content": "$1"
      }
    }
  },
  "SUGGESTION_ANSWER": {
    "message": "\"\u00bfC\u00f3mo estar\u00e1 el tiempo hoy?\""
  },
  "SUGGESTION_BLUETOOTH": {
    "message": "\"Activar Bluetooth\""
  },
  "SUGGESTION_CALL": {
    "message": "\"Llamar a M\u00f3nica\""
  },
  "SUGGESTION_CALL_EN_IN": {
    "message": "\"Llamar a M\u00f3nica\""
  },
  "SUGGESTION_PICTURES": {
    "message": "\"Mu\u00e9strame fotos de Shakira\""
  },
  "SUGGESTION_PICTURES_EN_IN": {
    "message": "\"Ver fotos de Lionel Messi\""
  },
  "SUGGESTION_SMS": {
    "message": "\"Enviar un mensaje a Juan\""
  },
  "SUGGESTION_SMS_EN_IN": {
    "message": "\"Enviar un mensaje a M\u00f3nica\""
  },
  "SUGGESTION_YOUTUBE": {
    "message": "\"Reproduce Ricky Martin en YouTube\""
  },
  "SUGGESTION_YOUTUBE_EN_IN": {
    "message": "\"Reproducir 'Despacito' en YouTube\""
  },
  "TERMS_AND_CONDITIONS_BODY_PRIVACY": {
    "message": "Presiona 2 para leer la Pol\u00edtica de Privacidad:"
  },
  "TERMS_AND_CONDITIONS_BODY_TERMS": {
    "message": "Presiona 1 para leer las Condiciones del servicio:"
  },
  "TERMS_AND_CONDITIONS_TITLE": {
    "message": "Lee las Condiciones del servicio y la Pol\u00edtica de Privacidad de Google"
  },
  "UDC_SETTINGS_LEARN_MORE_PROMPT": {
    "message": "Presiona $INDEX$ para obtener m\u00e1s informaci\u00f3n",
    "placeholders": {
      "INDEX": {
        "content": "$1"
      }
    }
  },
  "UNKNOWN_CONNECTION_ERROR": {
    "message": "Estamos teniendo problemas t\u00e9cnicos."
  },
  "VERSION_EXPIRED_ERROR": {
    "message": "La aplicaci\u00f3n est\u00e1 desactualizada. Comun\u00edcate con el proveedor para instalar la versi\u00f3n m\u00e1s reciente."
  }
};
