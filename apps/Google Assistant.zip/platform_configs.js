

class KaiOSConfigs {}


KaiOSConfigs.APP_VERSION = '3.2.1';


KaiOSConfigs.DEVICE_MODEL = 'KaiOSPhone';


KaiOSConfigs.WEB_SEARCH_CLIENT_ID = 'kaios';


KaiOSConfigs.DEFAULT_LOCALE = 'en-US';


KaiOSConfigs.PROD_API_KEY =
    'AIzaSyD7Iv9aafYD6tsjBxWWOFPUGgsNG5eloRA';  


KaiOSConfigs.PROD_SPEECH_SYNTHESIS_API_KEY =
    'AIzaSyCkWE464u-OwxXxcE_fxGzLAyffMq30KSs';  


KaiOSConfigs.REQUIRE_LOCATION_CONSENT = false;


KaiOSConfigs.LANGUAGES_NEED_REGION_NAME = ['en', 'es', 'fr'];


KaiOSConfigs.PROMPTS_FOR_MICROPHONE_PERMISSION = false;


KaiOSConfigs.YOUTUBE_APP_NAME = 'YouTubeApp';







var PlatformConfigs = KaiOSConfigs;
