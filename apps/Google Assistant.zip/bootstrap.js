// Bootstrapping happens after the GUI is shown in order to bring the UX as soon
// as possible.

var APP_START_TIME = Date.now();

window.addEventListener('load', function(event) {
  // Lazy load the flac encoder lib to avoid affecting app startup time.
  var flacEncoder = document.createElement('script');
  flacEncoder.type = 'text/javascript';
  flacEncoder.src = 'libflac3-1.3.2.min.js';
  document.head.appendChild(flacEncoder);
  if (navigator.mozBluetooth) {  // NOLINT
    // Just need to attempt to access navigator.mozBluetooth.defaultAdapter to
    // start its initialization.
    navigator.mozBluetooth.defaultAdapter;  // NOLINT
  }

  // Initialize the object where the translations live.
  window['opa'] = {'Messages': {}};

  new google.assistant.MainController(PlatformConfigs.APP_VERSION);

});
