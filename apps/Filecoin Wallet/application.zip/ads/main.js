 function createKaiAd() {
  console.log('creating add')
  window.getKaiAd({
    publisher: '8aea7e5d-a9cf-42bb-8f0c-e7f349921411',
    app: 'Filecoin',
    slot: 'Random',
    timeout: 5000,
    test:0,
    h: 60,
    w: 230,
    onerror: err => console.log('Ad error: ', err),
    onready: ad => {
      console.log('in ready')
      // let button = document.getElementById('t')
      // button.addEventListener('build', function btnListener() {
        // button.removeEventListener('build', btnListener)

        // calling 'display' will display the ad
        console.log('in the listner')
        ad.call('display')
        // createKaiAd()

      // })
      // user clicked the ad
      ad.on('click', () => {
        console.log('click event')
        var message = document.getElementById("qr");
        message.focus()
        // createKaiAd()
      })

      // user closed the ad (currently only with fullscreen)
      ad.on('close', () => {
        console.log('close event')
        var message = document.getElementById("qr");
        message.focus()
        // createKaiAd()
      })

      // the ad succesfully displayed
      ad.on('display', () => console.log('display event'))
    }
  });
}

createKaiAd()