var curlevel = +sessionStorage.getItem("curlevel");
var maxlevel = +localStorage.getItem("maxlevel");
var cwp = 0;
var mode="field";

var quiz = levels[curlevel-1];

function shuffle(arro) {
  for (let i = arro.length - 1; i > 0; i--) {
    let j = Math.floor(Math.random() * (i + 1));
    [arro[i], arro[j]] = [arro[j], arro[i]];
  }
}

function drawGrid() {
	
	for (var i=0;i<quiz.length;i++) {
		
		var div = document.createElement("div");
		div.id="word"+i;
		div.classList.add("worddiv");
		div.style.position = "absolute";
		div.style.left = ((quiz[i][0]-1)*20)+"px";
		div.style.top = ((quiz[i][1]-1)*20)+"px";
		if (quiz[i][2]=="hor") {
			div.style.width = (quiz[i][3].length*20)+"px";
			div.style.height = "20px";
		} else {
			div.style.height = (quiz[i][3].length*20)+"px";
			div.style.width = "20px";
		}
		div.setAttribute("word", "#".repeat(quiz[i][3].length));
		document.getElementById("grid").appendChild(div);
	}
	
	document.getElementById("word"+cwp).classList.remove("worddiv");
	document.getElementById("word"+cwp).classList.add("worddivfocus");
	document.getElementById("word"+cwp).style.zIndex = "10";
	
	document.getElementById("grid").classList.add("boxshadow");
	document.getElementById("variants").classList.remove("boxshadow");
}

function drawVariants() {
	
	var ttp = 0;
	var quizCopy = JSON.parse(JSON.stringify(quiz));
	shuffle(quizCopy);
	
	for (var i=0;i<quizCopy.length;i++) {
		
		var btn = document.createElement("button");
		btn.id="variant"+i;
		btn.classList.add("variantbtn");
		btn.classList.add("items");
		btn.style.position = "absolute";
		btn.tabIndex = i;
		var ppp = 0;
		if (i==4 || i==8 || i==12 || i==16 || i==20 || i==24) { ttp = ttp+16; }
		if (i==1 || i==5 || i==9 || i==13 || i==17 || i==21 || i==25) {ppp = 60; }
		if (i==2 || i==6 || i==10 || i==14 || i==18 || i==22 || i==26) {ppp = 120; }
		if (i==3 || i==7 || i==11 || i==15 || i==19 || i==23 || i==27) {ppp = 180; }
		btn.style.top = ttp+"px";
		btn.style.left = ppp+"px";
		btn.style.width = "60px";
		btn.style.height = "16px";
		btn.setAttribute("word", quizCopy[i][3]);
		btn.innerHTML=quizCopy[i][3];
		document.getElementById("variants").appendChild(btn);
	}
	
	  document.querySelectorAll('.items')[0].focus();

}

function navfield(move) {
	
	if (cwp+move>-1 && cwp+move<quiz.length) {
		
	for (var i=0;i<quiz.length;i++) {
	document.getElementById("word"+i).classList.remove("worddivfocus");
	document.getElementById("word"+i).classList.add("worddiv");
	document.getElementById("word"+i).style.zIndex = "0";
	}
	
	cwp = cwp+move;
	document.getElementById("word"+cwp).classList.remove("worddiv");
	document.getElementById("word"+cwp).classList.add("worddivfocus");
	document.getElementById("word"+cwp).style.zIndex = "10";
	
	if (document.getElementById("word"+cwp).getAttribute("word").indexOf("#")!=-1) { 
		document.getElementById("softkey-center").innerHTML="Select";
	} else { document.getElementById("softkey-center").innerHTML="Remove"; }
		
	} 
	
}

function navwords (move) {
  var currentIndex = document.activeElement.tabIndex;
  var items = document.querySelectorAll('.items');
  var next = currentIndex + move;
  if (next>items.length-1) {next=items.length-1;} else if (next<0) {next=0;}
  var targetElement = items[next];
  targetElement.focus();
};

function handleKeydown(e) {
  switch(e.key) {
    case 'ArrowUp':
      if (mode=="field") { navfield(-1); } else { navwords(-4); }
      break;
    case 'ArrowDown':
      if (mode=="field") { navfield(1); } else { navwords(4); }
      break;
	case 'ArrowLeft':
      if (mode=="field") { navfield(-1); } else { navwords(-1); }
      break;
    case 'ArrowRight':
      if (mode=="field") { navfield(1); } else { navwords(1); }
      break;
    case 'SoftLeft':
      softkeyCallback.left();
      break;
    case 'SoftRight':
      softkeyCallback.right();
      break;
    case 'Enter':
      softkeyCallback.center();
      break;	
	case 'Backspace':
	  e.preventDefault(); 
	  softkeyCallback.back();
	break;
  }
};


const softkeyCallback = {
	back: function() {
		window.open("index.html","_self");
	},
	
    left: function() { 
		if (mode=="field") { 
			mode="words"; 
			document.getElementById("softkey-left").innerHTML="Grid"; 
			document.getElementById("softkey-center").innerHTML="Put"; 
			document.getElementById("grid").classList.remove("boxshadow");
			document.getElementById("variants").classList.add("boxshadow");
		} else { 
		
		mode="field"; 
		
		document.getElementById("grid").classList.add("boxshadow");
		document.getElementById("variants").classList.remove("boxshadow");
		
	if (document.getElementById("word"+cwp).getAttribute("word").indexOf("#")!=-1) { 
		document.getElementById("softkey-center").innerHTML="Select";
	} else { document.getElementById("softkey-center").innerHTML="Remove"; }
		
		document.getElementById("softkey-left").innerHTML="Words"; 
		
		}
     },
  
    center: function() { 
		if (mode=="field") {
			if (document.getElementById("softkey-center").innerHTML=="Select") {
				mode="words";
				document.getElementById("softkey-left").innerHTML="Grid"; 
				document.getElementById("grid").classList.remove("boxshadow");
			    document.getElementById("variants").classList.add("boxshadow");
				document.getElementById("softkey-center").innerHTML="Put"; 
			} else if (document.getElementById("softkey-center").innerHTML=="Remove") {
				removeWord();
			}
			
		} else {
			
			if (quiz[cwp][3].length==document.activeElement.innerHTML.length &&
			document.activeElement.innerHTML.indexOf("•")==-1) {
				if (checkWord(document.activeElement.id)) {
				document.getElementById("softkey-left").innerHTML="Words";
				putWord(document.activeElement.id);
				checkWin();
				} else { drawError(document.activeElement.id); 	}
				} else { drawError(document.activeElement.id); 	}
			
		}
	
			
      },
  
    right: function() { 
		levelRestart();
     }
};

function levelRestart() {
	
if (window.confirm("Restart Level? All progress will be lost")) {
	
  cwp = 0;
  mode="field";
  localStorage.removeItem("save"+curlevel);
  document.getElementById("grid").innerHTML="";
  document.getElementById("variants").innerHTML="";
  document.getElementById("softkey-left").innerHTML="Words";
  document.getElementById("softkey-center").innerHTML="Select";
  
  drawGrid();
  drawVariants();
  
}
	
}

function checkWin() {
	
	var win = true;
	
	for (var i=0;i<quiz.length;i++) {
		if (document.getElementById("word"+i).getAttribute("word").indexOf("#")>-1) {
			win = false;
			break;
		}
	}
	
	if (win==true) { 
	document.removeEventListener('keydown', handleKeydown);
	document.getElementById("grid").classList.remove("boxshadow");
	document.getElementById("variants").classList.remove("boxshadow");
	curlevel++;
	
	if (curlevel>levels.length) {
		
	setTimeout(() => {
	document.getElementById("win").hidden=false;
	setTimeout(() => { window.open("index.html","_self"); }, 1750);
	}, 700);
		
	} else {
	
	sessionStorage.setItem("curlevel",curlevel);
	if (curlevel>maxlevel) { maxlevel=curlevel; localStorage.setItem("maxlevel",maxlevel);}
	
	setTimeout(() => {
	document.getElementById("win").hidden=false;
	
	setTimeout(() => {
		
	document.getElementById("win").hidden=true;
	quiz = levels[curlevel-1];
	cwp = 0;
    mode="field";
	document.getElementById("grid").innerHTML="";
	document.getElementById("variants").innerHTML="";
	document.getElementById("softkey-left").innerHTML="Words";
	document.getElementById("softkey-center").innerHTML="Select";
	drawGrid();
	drawVariants();
	restoreLevel();
	document.addEventListener('keydown', handleKeydown);	
	start_KaiAds();
	}, 1750);
		
	}, 700);
	
	}
	
	}
	
}

function removeWord() {
	
	for (var i=0;i<quiz[cwp][3].length;i++) {
		if (document.getElementById("toword"+cwp+"_"+i)) {
			document.getElementById("toword"+cwp+"_"+i).remove();
		}
	}
	
	for (var i=0;i<quiz.length;i++) {
		if (document.getElementById("variant"+i).getAttribute("word")==document.getElementById("word"+cwp).getAttribute("word")) {
			document.getElementById("variant"+i).innerHTML=document.getElementById("variant"+i).getAttribute("word");
		}
		
	}

	document.getElementById("word"+cwp).setAttribute("word", "#".repeat(quiz[cwp][3].length));
	document.getElementById("softkey-center").innerHTML="Select";
	
	saveLevel();
	
}

function checkWord(idd) {
	
	var correct = true;
	var masscoord = [];
	var masschar = [];
	
	for (var i=0;i<document.getElementById(idd).innerHTML.length;i++) {
		if (quiz[cwp][2]=="hor") {
			masscoord.push((quiz[cwp][0]+i)+"_"+quiz[cwp][1]);
		} else {
			masscoord.push(quiz[cwp][0]+"_"+(quiz[cwp][1]+i));
		}
		masschar.push(document.getElementById(idd).innerHTML[i]);
	}
	
	for (var i=0;i<quiz.length;i++) {
		for (var j=0;j<quiz[i][3].length;j++) {
			
		if (document.getElementById("toword"+i+"_"+j)) {
			
			var tempcoord = document.getElementById("toword"+i+"_"+j).getAttribute("coord");
			var tempchk = document.getElementById("toword"+i+"_"+j).innerHTML;
			
			for (var k=0;k<masscoord.length;k++) {
				
				if (masscoord[k]==tempcoord && masschar[k]!=tempchk) {
					correct=false;
					break;
				}
				
			}
			
		}			
			
		}
	}
	
	return correct;
	
}

function putWord(idd) {
	
	var xxx=((quiz[cwp][0]-1)*20)+10;
	var yyy=(quiz[cwp][1]-1)*20;
	
	for (var i=0;i<document.getElementById(idd).innerHTML.length;i++) {
		
		var div = document.createElement("div");
		div.id="toword"+cwp+"_"+i;
		div.classList.add("chardiv");
		div.style.position = "fixed";
		div.style.left = xxx+"px";
		div.style.top = yyy+"px";
		div.style.zIndex = "11";
		div.innerHTML=document.getElementById(idd).innerHTML[i];
		if (quiz[cwp][2]=="hor") {
			div.setAttribute("coord", (quiz[cwp][0]+i)+"_"+(quiz[cwp][1]));
			xxx=xxx+20;
		} else {
			div.setAttribute("coord", (quiz[cwp][0])+"_"+(quiz[cwp][1]+i));
			yyy=yyy+20;
		}
		
		document.getElementById("grid").appendChild(div);
		
	}
	
	document.getElementById("word"+cwp).setAttribute("word", document.getElementById(idd).innerHTML);
	document.getElementById(idd).innerHTML="•".repeat(document.getElementById(idd).innerHTML.length);
	mode="field";
	document.getElementById("grid").classList.add("boxshadow");
	document.getElementById("variants").classList.remove("boxshadow");
	document.getElementById("softkey-center").innerHTML="Remove";
	
	saveLevel();
}

function drawError(idd) {
	if (document.getElementById(idd)) {
	document.getElementById(idd).classList.add("errorbtn");
	document.getElementById("word"+cwp).classList.add("errorwrd");
	setTimeout(() => 
	{
	document.getElementById(idd).classList.remove("errorbtn");
	document.getElementById("word"+cwp).classList.remove("errorwrd");
	}, 500);
	}
}

function saveLevel() {
	var fieldmass = [];
	var charmass = [];
	var butmass = [];
	
	for (var i=0;i<quiz.length;i++) {
		fieldmass.push(document.getElementById("word"+i).getAttribute("word"));
		butmass.push(document.getElementById("variant"+i).innerHTML);
		butmass.push(document.getElementById("variant"+i).getAttribute("word"));
		
		if (document.getElementById("word"+i).getAttribute("word").indexOf("#")==-1) {
			
			for (var j=0;j<document.getElementById("word"+i).getAttribute("word").length;j++) {
			var temparr = [];
			temparr.push("toword"+i+"_"+j);
			temparr.push(document.getElementById("toword"+i+"_"+j).innerHTML);
			temparr.push(document.getElementById("toword"+i+"_"+j).getAttribute("coord"));
			charmass.push(temparr);
			}
		}
	}
	
	var allmass = [];
	allmass.push(fieldmass);
	allmass.push(butmass);
	allmass.push(charmass);
	localStorage.setItem("save"+curlevel, JSON.stringify(allmass));
}

function restoreLevel() {
	
	if (localStorage.getItem("save"+curlevel)) {
		
		var storedArray = JSON.parse(localStorage.getItem("save"+curlevel));
		
		for (var i=0;i<storedArray[0].length;i++) {
			document.getElementById("word"+i).setAttribute("word",storedArray[0][i]);
		}
		
		for (var i=0;i<storedArray[1].length;i=i+2) {
			document.getElementById("variant"+Math.round(i/2)).innerHTML=storedArray[1][i];
			document.getElementById("variant"+Math.round(i/2)).setAttribute("word",storedArray[1][i+1]);
		}
		
		for (var i=0;i<storedArray[2].length;i++) {
			var fid = storedArray[2][i][0];
			var ltr = storedArray[2][i][1];
			var fx = +storedArray[2][i][2].slice(0,storedArray[2][i][2].indexOf("_"));
			var fy = +storedArray[2][i][2].slice(storedArray[2][i][2].indexOf("_")+1);
			var xxxx=((fx-1)*20)+10;
			var yyyy=(fy-1)*20;
			
		var div = document.createElement("div");
		div.id=fid;
		div.classList.add("chardiv");
		div.style.position = "fixed";
		div.style.left = xxxx+"px";
		div.style.top = yyyy+"px";
		div.style.zIndex = "11";
		div.innerHTML=ltr;
		div.setAttribute("coord", fx+"_"+fy);
		document.getElementById("grid").appendChild(div);
		}
		
		
	if (document.getElementById("word"+cwp).getAttribute("word").indexOf("#")!=-1) { document.getElementById("softkey-center").innerHTML="Select";	} else { document.getElementById("softkey-center").innerHTML="Remove"; }
	}
	
}


document.addEventListener('keydown', handleKeydown);

drawGrid();
drawVariants();
restoreLevel();

function start_KaiAds() {

	getKaiAd({
	publisher: 'ef30ef98-e411-4952-89b7-4cf1e1bb4437',
	app: 'fillincrosswords',
	slot: 'fullscreen',
	test: 0,
	onerror: err => console.error('Custom catch:', err),
	onready: ad => {
		ad.call('display')
		
		ad.on('click', () => console.log('click event') )

		ad.on('close', () => document.addEventListener('keydown', handleKeydown) )

		ad.on('display', () => document.removeEventListener('keydown', handleKeydown) )
	}
})

}

document.addEventListener("DOMContentLoaded", () => {
start_KaiAds();
});