var day = new Date();
var D=day.getDate();
var saveday = +localStorage.getItem("day");
var maxlevel = +localStorage.getItem("maxlevel");
var easy = false;
var medium = false;
var hard = false;

var maxnum = levels.length;

if (saveday!=D && maxlevel<maxnum) { document.getElementById("softkey-left").innerHTML="Skip lvl"; }

var table = document.createElement("table");
table.classList.add("ltable");

for (var i=0;i<maxnum;i++) {
	
	var tr;
	var td;
	if (i==0 && !easy) {
    tr = document.createElement("tr");
	td = document.createElement("td");
	td.innerHTML="Easy (7x7)";
	td.id="eid";
	td.tabIndex=-1;
	td.colSpan = 5;
	td.style.color = "#00FF00";
	td.style.fontSize = "18px";
	tr.appendChild(td);
	table.appendChild(tr);
	easy=true;
    }
	if (i==15&& !medium) {
    tr = document.createElement("tr");
	td = document.createElement("td");
	td.innerHTML="Medium (9x9)";
	td.colSpan = 5;
	td.style.fontSize = "18px";
	td.style.color = "#FFFF00";
	tr.appendChild(td);
	table.appendChild(tr);
	medium=true;
    }
	if (i==40 && !hard) {
    tr = document.createElement("tr");
	td = document.createElement("td");
	td.innerHTML="Hard (11x11)";
	td.colSpan = 5;
	td.style.fontSize = "18px";
	td.style.color = "#FF0000";
	tr.appendChild(td);
	table.appendChild(tr);
	hard=true;
    }
	if (i % 5 == 0) {
    tr = document.createElement("tr");
	table.appendChild(tr);
            }
	td = document.createElement("td");
	td.classList.add("tfive");
	var button = document.createElement("button");
	button.id="lev"+(i+1);
	button.tabIndex=i;
	button.classList.add("items");
	button.classList.add("five");
	button.innerHTML=i+1;
	td.appendChild(button);
	tr.appendChild(td);

}

document.getElementById("content").appendChild(table);

for (var i=maxlevel+1;i<=maxnum;i++) {
	document.getElementById("lev"+i).style.color="#878787";
	document.getElementById("lev"+i).style.border="1px solid #878787";
}

function handleKeydown(e) {
  switch(e.key) {
    case 'ArrowUp':
	  e.preventDefault();
      nav(-5);
      break;
    case 'ArrowDown':
	  e.preventDefault();
      nav(5);
      break;
    case 'ArrowRight':
      nav(1);
      break;
    case 'ArrowLeft': 
      nav(-1);
      break;
    case 'SoftLeft':
      softkeyCallback.left();
      break;
    case 'SoftRight':
      softkeyCallback.right();
      break;
    case 'Enter':
      softkeyCallback.center();
      break;
	case 'Backspace':
	    e.preventDefault();
		softkeyCallback.back();		
	break;

  }
};

function nav (move) {
  var currentIndex = document.activeElement.tabIndex;
  if (currentIndex==-1) { currentIndex=0; }
  var items = document.querySelectorAll('.items');
  var next = currentIndex;
  if ((currentIndex + move<items.length) && (currentIndex + move>=0) ) {next = currentIndex + move;}
  var targetElement = items[next];
  if (currentIndex<6) { document.getElementById("eid").focus(); }
  targetElement.focus();
};



const softkeyCallback = {
	back: function() { 
      window.open("index.html","_self");
     },
	
	
    left: function() { 
       if (document.getElementById("softkey-left").innerHTML=="Skip lvl") {
		   maxlevel++;
		   localStorage.setItem("maxlevel",maxlevel);
		   sessionStorage.setItem("curlevel",maxlevel);
		   localStorage.setItem("day",D);
		   document.location.reload(true);
	   }
     },
  
    center: function() { 
	var chk = document.activeElement;
    if (chk.id.indexOf("lev")!=-1) {
		  if (+chk.innerHTML<=maxlevel) {
			  sessionStorage.setItem("curlevel",chk.innerHTML);
			  window.open("play.html","_self");
		  }
	  }

      },
  
    right: function() { 
		window.open("index.html","_self");
     }
};

document.addEventListener('keydown', handleKeydown);

window.addEventListener("load", function() {
  var items = document.querySelectorAll('.items');
  var targetElement = items[maxlevel-1];
  targetElement.focus();
});