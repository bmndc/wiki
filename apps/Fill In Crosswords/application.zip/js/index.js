var maxlevel = +localStorage.getItem("maxlevel");
var curlevel;
if (maxlevel==0) {curlevel=1; localStorage.setItem("maxlevel","1"); } else {curlevel=maxlevel;}

function handleKeydown(e) {
  switch(e.key) {
    case 'ArrowUp':
      nav(-1);
      break;
    case 'ArrowDown':
      nav(1);
      break;
    case 'SoftLeft':
      softkeyCallback.left();
      break;
    case 'SoftRight':
      softkeyCallback.right();
      break;
    case 'Enter':
      softkeyCallback.center();
      break;	
  }
};

function nav (move) {
  var currentIndex = document.activeElement.tabIndex;
  var items = document.querySelectorAll('.items');
  var next = currentIndex + move;
  if (next>items.length-1) {next=items.length-1;} else if (next<0) {next=0;}
  var targetElement = items[next];
  targetElement.focus();
};



const softkeyCallback = {

    left: function() { 

     },
  
    center: function() { 
	
	var chk = document.activeElement;
	
	if (chk.id=="play") { 
	sessionStorage.setItem("curlevel",curlevel);
	window.open("play.html","_self");
	}
	
	if (chk.id=="levels") { window.open("levels.html","_self");  }
	if (chk.id=="help") { window.open("help.html","_self");  }

      },
  
    right: function() { 
	
     }
};

document.addEventListener('keydown', handleKeydown);

window.addEventListener("load", function() {
  var items = document.querySelectorAll('.items');
  var targetElement = items[0];
  targetElement.focus();
});