function readDB(cb) {
    var openDB = indexedDB.open('appData', 1);
    openDB.onupgradeneeded = function () {
        console.log('coming inside the indexedDB onupgradeneeded call back');
        var db = openDB.result;
        db.createObjectStore('appData');
    };

    openDB.onsuccess = function () {
        console.log('coming inside the indexedDB onsuccess call back');
        // Start a new transaction
        var db = openDB.result;
        var tx = db.transaction(['appOptionsData', 'notificationStringsData'], 'readonly');
        var pushStore = tx.objectStore('appOptionsData');
        var notificationStringsDataStore = tx.objectStore('notificationStringsData');
        pushStore.get('appOptionsData').onsuccess = function (event) {
            var appOptionsData = event.target.result;
            notificationStringsDataStore.get('notificationStringsData').onsuccess = function (
                event
            ) {
                var notificationStringsData = event.target.result;
                cb({
                    notificationsEnabled: appOptionsData.notificationsEnabled,
                    notificationStringsData: notificationStringsData,
                });
            };
        };
        tx.oncomplete = function () {
            db.close();
        };
    };
}

self.addEventListener('activate', function (event) {
    console.log('self.activate', event);
});

self.addEventListener('install', function (event) {
    //can be cause of byte diff in sw, or first time, can set cache to preload resources
    console.log('service worker installing...', event);
});
var icon = '/img/icons/192px.png';

var DISMISS_ACTION = 'DISMISS_ACTION';
var READ_ACTION = 'READ_ACTION';
var getActions = function (notificationStrings) {
    var dismissString = 'Dismiss',
        readString = 'Read';
    if (notificationStrings) {
        dismissString = notificationStrings.dismissAction || dismissString;
        readString = notificationStrings.readAction || readString;
    }
    return [
        {
            action: DISMISS_ACTION,
            title: dismissString,
        },
        {
            action: READ_ACTION,
            title: readString,
        },
    ];
};
var pushHandlerMap = {
    mail: function (notificationStrings, event) {
        /**
         * @example NewMail
         * {
         * "SenderName": "Shishir Arora",
         * "SenderEmail":"Shishir.Arora@microsoft.com",
         * "Subject":"test",
         * "BodyPreview":"Regards,\r\nShishir Arora\r\nSr SOFTWARE ENGINEER\r\nOutlook (Consumer/Enterprise) for the Mobile Web\r\nOffice 365 ( OPG )\r\nSeat no. 8362 on 8th floor, prestige ferns, bangalore\r\nEmp id:6062057\r\nMobile: +91 7042228993\r\nShiarora@microsoft.com\r\n9 AM - 6 PM\r\nBo",
         * "MessageId":"AQMkADAwATM3ZmYAZS0yOTY1LTI0MmYtMDACLTAwCgBGAAADDknoCuydTEaj1IcpU6J0jAcATtCAdxv3r0mhMgMNuBBnOQAAAgEMAAAATtCAdxv3r0mhMgMNuBBnOQAAAKsZwHIAAAA=",
         * "NotificationType":"NewMail",
         * "NotificationOptics":{
         *          "AnalyticsEnabled":true,
         *              "AnalyticsVersion":1,
         *              "AriaToken":"56468f6991c348029c6bba403b444607-7f5d6cd1-7fbe-4ab1-be03-3b2b6aeb3eb4-7696",
         *              "Dag":"APCPR06DG073",
         *              "Forest":"apcprd06",
         *              "Region":"apc",
         *              "Machine":"PS2PR06MB2551",
         *              "Ring":"WW",
         *              "RoleVersion":"15.20.3477.27",
         *              "ClientId":"456C8C7161744574AF5A2314A7DA10D3",
         *              "Puid":"00037FFE2965242F",
         *              "TenantId":"84df9e7f-e9f6-40af-b435-aaaaaaaaaaaa",
         *              "SentTimeStamp":1603355914480
         *              }
         * }
         */
        var jsonMessage = '';
        if (event.data !== undefined) {
            jsonMessage = JSON.parse(event.data.text());
        }
        console.log(jsonMessage);
        var senderName = jsonMessage.SenderName;
        var newMailString = 'New email';

        if (notificationStrings) {
            newMailString = notificationStrings.newMail || newMailString;
        }
        var appLaunchPayload = {
            eventName: 'renderAppWithNewRoute',
            route: `/messages/email`,
        };
        var payload = {
            body: senderName,
            icon: icon,
            data: appLaunchPayload,
            requireInteraction: true,
            mozbehavior: {
                soundFile: '/public/assets/sounds/new_email.ogg',
                showOnlyOnce: true,
            },
            actions: getActions(notificationStrings),
            tag: jsonMessage.MessageId, //used to identify a notification instance
            appLaunchPayload: appLaunchPayload,
        };
        return {
            payload: payload,
            title: newMailString,
        };
    },
    reminder: function (notificationStrings, event) {
        //can receive messages form other context here
        console.log('service worker reminder received...', event.data);
        var payload = {
            body: event.data.body,
            appLaunchPayload: event.data.appLaunchPayload,
            icon: icon,
            data: event.data.appLaunchPayload,
            requireInteraction: true,
            mozbehavior: {
                soundFile: '/public/assets/sounds/calendar_reminder.ogg',
                showOnlyOnce: true,
            },
            actions: getActions(notificationStrings),
            tag: event.data.id, //used to identify a notification instance
        };
        return {
            payload: payload,
            title: event.data.title,
        };
    },
    sms: function (notificationStrings, event) {
        //can receive messages form other context here
        console.log('service worker sms received...', event.data);
        var payload = {
            body: event.data.body,
            appLaunchPayload: event.data.appLaunchPayload,
            icon: icon,
            data: event.data.appLaunchPayload,
            requireInteraction: event.data.requireInteraction,
            mozbehavior: {
                soundFile: '/public/assets/sounds/calendar_reminder.ogg',
                showOnlyOnce: true,
            },
            actions: event.data.actions,
            tag: event.data.id, //used to identify a notification instance
        };
        return {
            payload: payload,
            title: event.data.title,
        };
    },
};
var handlePush = function (event) {
    console.log('[Service-Worker]: handlePush', event);
    readDB(function (appData) {
        try {
            if (!appData.notificationsEnabled) {
                console.log('service worker push received...Notifications are not enabled');
                return;
            }
            var config = pushHandlerMap[event.data.type](appData.notificationStringsData, event);
            try {
                self.registration.showNotification(config.title, config.payload);
            } catch (e) {
                console.error('showNotification', e);
            }
        } catch (e) {
            console.log(e);
        }
    });
};

self.addEventListener('push', function (event) {
    console.log('[Service-Worker]: push:', event);
    event.data.type = 'mail';
    handlePush(event);
});
self.addEventListener('message', handlePush);

self.addEventListener('notificationclick', function (event) {
    console.log('self.notificationclick', JSON.stringify(event.notification.data));
    event.notification.close();
    console.log('[SW] inside show ' + event.notification.data);
    var action = event.action;
    if (action === DISMISS_ACTION) {
    } else {
        //read action
        if (event.notification.data !== undefined) {
            var openAppEvent = {
                msg: JSON.stringify(event.notification.data),
            };
            event.waitUntil(clients.openApp(openAppEvent));
        }
    }
});
